# Font Finder

Windows desktop prototype for offline font discovery.

## Current MVP
- Loads common image formats.
- Scans font families installed in Windows.
- Lets the user enter the text visible in the image.
- Ranks up to 20 installed font families using a simple normalized-shape comparison.
- Previews the selected font.

## Important limitations
The score is a rough visual similarity score, not proof of exact font identity. Best results need a tightly cropped, high-contrast, single-line sample with little decoration. Automatic OCR, robust Persian/Arabic shaping and segmentation, logos/decorative lettering, multiple text regions, external font folders, and installer packaging are not yet implemented.
