# Engine development plan

1. Current MVP: offline comparison of a normalized image silhouette against installed-font renderings, using user-entered text.
2. Improve preprocessing: background removal, polarity detection, thresholding, crop detection, scale/spacing normalization.
3. Add reliable OCR and RTL shaping as optional text extraction; retain manual text entry fallback.
4. Compare glyph-level features and word-level geometry; support isolated glyphs, Persian/Arabic dots and ligatures.
5. Add user-selected font folders and direct TTF/OTF loading without installation.
6. Package and test on target Windows versions.

The current similarity score is only a heuristic and must not be presented as guaranteed font identification.
