using System.Windows;

namespace FontFinder
{
    public partial class App : Application
    {
    }
}
