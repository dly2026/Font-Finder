# Engine notes

## Pipeline
image + crop -> `SignatureBuilder` (Otsu threshold, border-based polarity, tight ink box, 64x64 area-sampled mask)
font + text -> `GlyphRenderer` (single line, NoWrap, shrink-to-fit) -> same `SignatureBuilder`
`ShapeScorer.Combined` = 0.70 form + 0.20 pattern + 0.10 proportions.

## Prefilter (`FontMatcher.SelectShortlist`)
Only when installed families > limit (default 500). 60% closest aspect ratio; 40% spread evenly across the
wider and the narrower remainder. Aspect ratio is measured on the tight ink box (same measure as the target)
or taken from a cached signature. It never excludes a family on its own beyond the shortlist size.

## Cache
`SignatureStore`: memory + disk, atomic write (temp + move), FNV-1a checksum, auto-repair.
Key = render version | family | style | font metrics fingerprint | glyph/text mode | text.

## Not done / ideas
* Calibrate score scaling (chamfer scale 24 gives compressed scores) with labelled crops.
* Optional glyph pre-warm for A-Z/0-9 per font.
* Cancel button; per-user font enumeration.
