# Changes in this revision (vs. FontFinder-Simple-Ranking-BuildReady-Audit2)

1. csproj: `Microsoft.NET.Sdk` + `UseWPF`, `System.Drawing` / `System.Configuration` references, App.config.
2. Code split into focused files (engine separated from UI); MainWindow no longer imports System.Drawing.
3. No empty `catch`: failures are collected, logged and counted in the status line.
4. Style fallback Regular -> Bold -> Italic -> Bold Italic.
5. Atomic, checksummed font cache with automatic repair of corrupt files.
6. Per-glyph cache (font + character) independent of the search text; metrics fingerprint in the key.
7. NoWrap single-line rendering; Otsu threshold and border-based polarity; area-sampled 64x64 mask.
8. Prefilter rewritten (fair, two-sided, no width-only elimination).
9. Real descriptive categories (Category column, never a filter).
10. Results-cache key adds file time/size, limits, font-list fingerprint; invariant culture formatting;
    crop clamping at image edges and re-alignment on resize; typography text reset on clear.
11. Progress bar, Clear font cache button, `.gitignore`, `--selftest`, CI runs the self-test.
