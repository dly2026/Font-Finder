# Font Finder

Offline Windows (WPF, C#, .NET Framework 4.8) tool that suggests installed fonts visually similar to a
cropped letter, number or short text taken from an image.

> **Status:** source-reviewed and refactored, **not yet built or run on Windows by the author of this
> revision.** The GitHub Actions workflow builds the project and runs a built-in self-test on
> `windows-latest`; trust that run, not this sentence.

## How it works

1. **Crop** the glyph or text in the image. The crop is clamped to the image bounds.
2. Type the **exact visible text**. A single character is cached per font and glyph (independent of
   other text); multi-character text is cached per font and text.
3. **Prefilter** (only when more than 500 families are installed): a soft aspect-ratio estimate picks
   the 300 closest families and spreads the remaining 200 evenly over wider and narrower families, so unusual
   widths are not dropped. With 500 or fewer families, all are compared.
4. **Detailed ranking** of every shortlisted family (no threshold, no single-feature elimination):

   | Component | Weight |
   |---|---|
   | Overall form (symmetric chamfer distance of silhouettes) | 70% |
   | Shape pattern (row/column ink projections) | 20% |
   | Proportions (aspect ratio, ink density, visual centre) | 10% |

   Up to **100** results are shown. Scores are heuristic similarity values, not probabilities.
5. **Categories** (Serif, Sans Serif, Script, Display, Monospaced, Bitmap, Symbol, Unknown) are descriptive
   only and never filter the search. They come from conservative name rules plus a monospace width
   measurement; anything uncertain is **Unknown**.

## Caches (independent)

* **Font signature cache** - `%LOCALAPPDATA%\FontFinder\Signatures`. Persistent, atomic writes,
  checksummed; unreadable files are deleted and rebuilt automatically. Keys include a font metrics
  fingerprint so a replaced font is not served stale data. Button: *Clear font cache*.
* **Search results cache** - in memory only. Key includes the image path, file time and size, crop, text,
  limits and the installed-font list. Button: *Clear search cache*.

Errors (fonts that cannot be rendered, cache problems) are logged to
`%LOCALAPPDATA%\FontFinder\Logs\FontFinder.log`; the status line reports how many fonts were skipped.

## Settings

`FontFinder.exe.config` (`App.config`): `CandidateLimit` (20-500, default 500) and `ResultLimit` (1-100, default 100).

## Build

```
msbuild src/FontFinder/FontFinder.csproj /restore /p:Configuration=Release
```

Requires Visual Studio 2019/2022 Build Tools (or the .NET SDK on Windows). No network access is needed at run time.

## Self-test

`FontFinder.exe --selftest [results-file]` runs the built-in checks (cache atomicity and repair, crop edges,
score weights, culture independence, prefilter coverage, category rules, an end-to-end ranking test) without
opening the UI. Exit code 0 = pass. CI runs it after every build.

## Known limitations

* Matching uses GDI+ rendering of **installed** families (Regular, else Bold/Italic). Per-user fonts that GDI+ does not enumerate are not seen.
* Very small or low-contrast crops give unreliable results; scores are not calibrated on labelled data.
* Arabic/Persian-script fonts are mostly categorised as Unknown (the categories target Latin typography).
* Multi-character text is cached per text, not per glyph.
