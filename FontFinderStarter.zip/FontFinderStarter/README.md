# Font Finder

Windows desktop prototype for offline font discovery.

## Current MVP
- Loads common image formats.
- Scans font families installed in Windows.
- Lets the user enter the text visible in the image.
- Ranks up to 20 installed font families using normalized glyph masks and symmetric chamfer-distance shape matching.
- Previews the selected font.

## Important limitations
The score is an experimental visual similarity score, not proof of exact font identity. The current matcher is a classical image-processing method, not a neural-network model. Best results need a tightly cropped, high-contrast, single-line sample with little decoration. Automatic OCR, robust Persian/Arabic shaping and segmentation, logos/decorative lettering, multiple text regions, external font folders, and installer packaging are not yet implemented.
\n## UI update\n- Results list now has a persistent live preview pane.\n- Selecting a font updates the preview immediately.\n- Up/Down arrows browse result rows; preview zoom is adjustable.\n- The matcher has been upgraded from raw pixel subtraction to polarity-aware glyph masks and symmetric chamfer-distance comparison. It remains an experimental heuristic and is not a neural-network engine.\n