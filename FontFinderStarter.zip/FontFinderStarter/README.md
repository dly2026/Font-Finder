# Font Finder

A free, offline-first Windows desktop application project.

## Current prototype status

This initial foundation provides:
- A WPF desktop window.
- Image selection and preview.
- Enumeration of installed font families.
- Manual sample-text entry and font preview.

It does **not yet** implement reliable automatic image-to-font identification or ranked visual matching. Those require a dedicated image-matching engine and a test corpus. Do not describe this prototype as a completed font recognizer.

## Build

The project targets .NET Framework 4.8 and WPF. Build on a Windows machine/runner with the .NET Framework 4.8 targeting pack and MSBuild available.

Project: `src/FontFinder/FontFinder.csproj`
