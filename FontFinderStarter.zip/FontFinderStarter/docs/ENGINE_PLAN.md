# Visual Matching Engine Plan

The recognition engine is not implemented in this starter.

Planned stages:
1. Image crop, background removal, grayscale and threshold normalization.
2. Optional manual text input; OCR remains optional and local.
3. Render the same text in candidate fonts with correct script shaping.
4. Compare normalized glyph masks, contours, stroke width and spacing.
5. Rank candidates and calibrate confidence on a labeled test set.
6. For unknown text/logo samples, evaluate text-independent shape descriptors separately; do not claim exact identification without validation.

Persian and Arabic require correct shaping, RTL layout and contextual glyph forms. Decorative lettering and logos may remain ambiguous, especially with very short samples.
