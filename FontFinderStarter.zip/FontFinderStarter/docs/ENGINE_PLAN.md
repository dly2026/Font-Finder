# Engine development plan

1. Current offline MVP: compare a user-selected image crop with renderings from installed Windows font families.
2. Current matcher uses polarity-aware thresholding, scale-normalized glyph masks, symmetric chamfer distance maps, and an aspect-ratio penalty. This is more tolerant of small edge and alignment differences than raw pixel subtraction.
3. Next: improve glyph segmentation, baseline and spacing analysis, multiple font weights/styles, and better handling of noisy or colored samples.
4. Add reliable OCR and RTL shaping as optional text extraction; retain manual text entry fallback.
5. Compare glyph-level features and word-level geometry; support Persian/Arabic dots and ligatures.
6. Add user-selected font folders and direct TTF/OTF loading without installation.
7. Package and test on target Windows versions.

The current score is a heuristic ranking, not a calibrated probability or guaranteed font identification. The matcher is not a neural-network model.
