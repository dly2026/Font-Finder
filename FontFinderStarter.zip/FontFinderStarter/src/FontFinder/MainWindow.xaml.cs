﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Linq;
using System.Collections.Concurrent;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace FontFinder
{
    public partial class MainWindow : Window
    {
        private string _imagePath;
        private List<FontRow> _fontRows = new List<FontRow>();
        private const int Size = 48;
        private bool _isCropping;
        private System.Windows.Point _cropStart;
        private double _cropX, _cropY, _cropWidth, _cropHeight;
        private bool _hasCrop;
        private const int ProcessingMaxSide = 256;
        private static readonly Dictionary<string, ShapeSignature> FontSignatureCache =
            new Dictionary<string, ShapeSignature>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, List<FontRow>> _searchResultsCache =
            new Dictionary<string, List<FontRow>>(StringComparer.OrdinalIgnoreCase);

        public MainWindow() { InitializeComponent(); }

        private void ChooseImage_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog { Title = "Choose an image", Filter = "Image files|*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.tif;*.tiff|All files|*.*" };
            if (dialog.ShowDialog() == true)
            {
                try
                {
                    var image = new BitmapImage();
                    image.BeginInit(); image.CacheOption = BitmapCacheOption.OnLoad; image.UriSource = new Uri(dialog.FileName); image.EndInit();
                    InputImage.Source = image; _imagePath = dialog.FileName; ImagePathText.Text = dialog.FileName;
                    _hasCrop = false; CropRectangle.Visibility = Visibility.Collapsed; CropPreviewImage.Source = null;
                    StatusText.Text = "Image loaded. Enter its visible text, then click Find similar fonts.";
                }
                catch (Exception ex) { MessageBox.Show("Could not load image: " + ex.Message, "Font Finder", MessageBoxButton.OK, MessageBoxImage.Error); }
            }
        }

        private void ClearImage_Click(object sender, RoutedEventArgs e)
        {
            InputImage.Source = null; _imagePath = null; _hasCrop = false; CropRectangle.Visibility = Visibility.Collapsed;
            CropPreviewImage.Source = null;
            ImagePathText.Text = "No image selected"; StatusText.Text = "Image cleared.";
        }

        private void ScanFonts_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var fonts = new InstalledFontCollection())
                {
                    _fontRows = fonts.Families.Select(f => new FontRow { Family = f.Name, Style = "Installed", Similarity = "" })
                        .OrderBy(f => f.Family, StringComparer.CurrentCultureIgnoreCase).ToList();
                    FontsGrid.ItemsSource = null; FontsGrid.ItemsSource = _fontRows;
                    if (_fontRows.Count > 0) FontsGrid.SelectedIndex = 0;
                    UpdateLivePreview();
                    StatusText.Text = _fontRows.Count + " installed font families found.";
                }
            }
            catch (Exception ex) { StatusText.Text = "Font scan failed: " + ex.Message; }
        }

        private void FindSimilar_Click(object sender, RoutedEventArgs e)
        {
            if (InputImage.Source == null || string.IsNullOrWhiteSpace(_imagePath))
            { StatusText.Text = "First choose an image."; return; }
            string sample = SampleTextBox.Text ?? "";
            if (string.IsNullOrWhiteSpace(sample)) { StatusText.Text = "Enter the text visible in the image."; return; }
            if (_fontRows.Count == 0) ScanFonts_Click(sender, e);
            try
            {
                StatusText.Text = "Preparing a small image for matching...";
                string cacheKey = _imagePath + "|" + _hasCrop + "|" + _cropX.ToString("0.0") + "|" + _cropY.ToString("0.0") + "|" + _cropWidth.ToString("0.0") + "|" + _cropHeight.ToString("0.0") + "|" + sample;
                List<FontRow> best;
                if (_searchResultsCache.TryGetValue(cacheKey, out best))
                {
                    best = best.Select(x => new FontRow { Family = x.Family, Style = x.Style, Score = x.Score, Similarity = x.Similarity }).ToList();
                    StatusText.Text = "Loaded results from search cache...";
                }
                else
                {
                    var target = MakeImageSignature(_imagePath, _cropX, _cropY, _cropWidth, _cropHeight, _hasCrop);
                    var scored = new List<FontRow>();
                    foreach (var row in _fontRows)
                    {
                        try
                        {
                            string fontKey = row.Family + "|" + sample;
                            ShapeSignature candidate;
                            lock (FontSignatureCache)
                            {
                                if (!FontSignatureCache.TryGetValue(fontKey, out candidate))
                                {
                                    candidate = MakeFontSignature(row.Family, sample);
                                    FontSignatureCache[fontKey] = candidate;
                                }
                            }
                            double similarity = CompareSignatures(target, candidate);
                            scored.Add(new FontRow { Family = row.Family, Style = row.Style, Score = similarity, Similarity = similarity.ToString("0.0") + "%" });
                        }
                        catch { }
                    }
                    best = scored.OrderByDescending(x => x.Score).Take(20).ToList();
                    _searchResultsCache[cacheKey] = best.Select(x => new FontRow { Family = x.Family, Style = x.Style, Score = x.Score, Similarity = x.Similarity }).ToList();
                }
                FontsGrid.ItemsSource = best;
                if (best.Count > 0) FontsGrid.SelectedIndex = 0;
                UpdateLivePreview();
                StatusText.Text = "Checked " + _fontRows.Count + " installed fonts. Showing up to 20 closest visual matches. Treat scores as approximate.";
            }
            catch (Exception ex) { StatusText.Text = "Comparison failed: " + ex.Message; }
        }

        private const int SignatureSize = 64;

        private static ShapeSignature MakeImageSignature(string path, double cx, double cy, double cw, double ch, bool useCrop)
        {
            using (var original = new Bitmap(path))
            {
                Rectangle sourceRect = new Rectangle(0, 0, original.Width, original.Height);
                if (useCrop)
                {
                    int x = Math.Max(0, Math.Min(original.Width - 1, (int)Math.Round(cx)));
                    int y = Math.Max(0, Math.Min(original.Height - 1, (int)Math.Round(cy)));
                    int w = Math.Max(1, Math.Min(original.Width - x, (int)Math.Round(cw)));
                    int h = Math.Max(1, Math.Min(original.Height - y, (int)Math.Round(ch)));
                    sourceRect = new Rectangle(x, y, w, h);
                }
                double factor = Math.Min(1.0, (double)ProcessingMaxSide / Math.Max(sourceRect.Width, sourceRect.Height));
                int smallW = Math.Max(1, (int)Math.Round(sourceRect.Width * factor));
                int smallH = Math.Max(1, (int)Math.Round(sourceRect.Height * factor));
                using (var cropped = new Bitmap(smallW, smallH))
                using (var g = Graphics.FromImage(cropped))
                {
                    g.Clear(Color.White);
                    g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                    g.DrawImage(original, new Rectangle(0, 0, cropped.Width, cropped.Height), sourceRect, GraphicsUnit.Pixel);
                    return BuildSignature(cropped, true);
                }
            }
        }

        private static ShapeSignature MakeFontSignature(string family, string text)
        {
            using (var bmp = new Bitmap(640, 360))
            using (var g = Graphics.FromImage(bmp))
            {
                g.Clear(Color.White);
                g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
                float fontSize = 150f;
                System.Drawing.Font font = null;
                try
                {
                    for (int attempt = 0; attempt < 6; attempt++)
                    {
                        if (font != null) font.Dispose();
                        font = new System.Drawing.Font(family, fontSize, System.Drawing.FontStyle.Regular, GraphicsUnit.Pixel);
                        SizeF measured = g.MeasureString(text, font, 570);
                        if (measured.Width <= 570 && measured.Height <= 300) break;
                        fontSize *= 0.82f;
                    }
                    using (font)
                    using (var brush = new SolidBrush(Color.Black))
                    using (var format = new StringFormat
                    {
                        Alignment = StringAlignment.Center,
                        LineAlignment = StringAlignment.Center,
                        FormatFlags = StringFormatFlags.NoClip |
                            (text.Any(ch => ch >= 0x0600 && ch <= 0x06FF) ? StringFormatFlags.DirectionRightToLeft : 0)
                    })
                        g.DrawString(text, font, brush, new RectangleF(24, 18, 592, 324), format);
                }
                catch
                {
                    if (font != null) font.Dispose();
                    throw;
                }
                return BuildSignature(bmp, false);
            }
        }

        // Scale-normalized binary glyph mask plus a distance map for tolerant shape matching.
        private static ShapeSignature BuildSignature(Bitmap source, bool detectPolarity)
        {
            int width = source.Width, height = source.Height;
            var gray = new byte[width * height];
            long borderTotal = 0;
            int borderCount = 0;
            for (int y = 0; y < height; y++)
                for (int x = 0; x < width; x++)
                {
                    Color c = source.GetPixel(x, y);
                    byte value = (byte)((c.R * 299 + c.G * 587 + c.B * 114) / 1000);
                    gray[y * width + x] = value;
                    if (x < 3 || y < 3 || x >= width - 3 || y >= height - 3)
                    { borderTotal += value; borderCount++; }
                }

            bool darkInk = !detectPolarity || borderTotal / Math.Max(1, borderCount) >= 127;
            int threshold = darkInk ? 185 : 70;
            var raw = new bool[width * height];
            int minX = width, minY = height, maxX = -1, maxY = -1;
            for (int y = 0; y < height; y++)
                for (int x = 0; x < width; x++)
                {
                    int value = gray[y * width + x];
                    bool ink = darkInk ? value < threshold : value > threshold;
                    raw[y * width + x] = ink;
                    if (ink) { minX = Math.Min(minX, x); maxX = Math.Max(maxX, x); minY = Math.Min(minY, y); maxY = Math.Max(maxY, y); }
                }

            var mask = new bool[SignatureSize * SignatureSize];
            if (maxX < minX || maxY < minY) return new ShapeSignature(mask, 1.0);
            int boxW = maxX - minX + 1, boxH = maxY - minY + 1;
            double aspect = (double)boxW / Math.Max(1, boxH);
            double scale = Math.Min((SignatureSize - 8.0) / boxW, (SignatureSize - 8.0) / boxH);
            int destW = Math.Max(1, (int)Math.Round(boxW * scale));
            int destH = Math.Max(1, (int)Math.Round(boxH * scale));
            int offsetX = (SignatureSize - destW) / 2, offsetY = (SignatureSize - destH) / 2;
            for (int y = 0; y < destH; y++)
                for (int x = 0; x < destW; x++)
                {
                    int sx = minX + Math.Min(boxW - 1, (int)(x / scale));
                    int sy = minY + Math.Min(boxH - 1, (int)(y / scale));
                    mask[(offsetY + y) * SignatureSize + offsetX + x] = raw[sy * width + sx];
                }
            return new ShapeSignature(mask, aspect);
        }

        private static double CompareSignatures(ShapeSignature a, ShapeSignature b)
        {
            double forward = DirectedChamfer(a.Mask, b.DistanceMap);
            double backward = DirectedChamfer(b.Mask, a.DistanceMap);
            double chamfer = (forward + backward) / 2.0;
            double ratioPenalty = Math.Min(8.0, Math.Abs(Math.Log(Math.Max(0.01, a.AspectRatio) / Math.Max(0.01, b.AspectRatio))) * 5.0);
            return Math.Max(0.0, Math.Min(100.0, 100.0 * (1.0 - (chamfer + ratioPenalty) / 24.0)));
        }

        private static double DirectedChamfer(bool[] sourceMask, float[] targetDistance)
        {
            double sum = 0; int count = 0;
            for (int i = 0; i < sourceMask.Length; i++)
                if (sourceMask[i]) { sum += Math.Min(24.0, targetDistance[i]); count++; }
            return count == 0 ? 24.0 : sum / count;
        }

        private sealed class ShapeSignature
        {
            public bool[] Mask { get; private set; }
            public float[] DistanceMap { get; private set; }
            public double AspectRatio { get; private set; }

            public ShapeSignature(bool[] mask, double aspectRatio)
            {
                Mask = mask; AspectRatio = aspectRatio; DistanceMap = BuildDistanceMap(mask);
            }

            private static float[] BuildDistanceMap(bool[] mask)
            {
                const float diagonal = 1.41421356f;
                var distance = new float[mask.Length];
                for (int i = 0; i < mask.Length; i++) distance[i] = mask[i] ? 0f : 1000f;
                for (int y = 0; y < SignatureSize; y++)
                    for (int x = 0; x < SignatureSize; x++)
                    {
                        int i = y * SignatureSize + x; float d = distance[i];
                        if (x > 0) d = Math.Min(d, distance[i - 1] + 1f);
                        if (y > 0) d = Math.Min(d, distance[i - SignatureSize] + 1f);
                        if (x > 0 && y > 0) d = Math.Min(d, distance[i - SignatureSize - 1] + diagonal);
                        if (x < SignatureSize - 1 && y > 0) d = Math.Min(d, distance[i - SignatureSize + 1] + diagonal);
                        distance[i] = d;
                    }
                for (int y = SignatureSize - 1; y >= 0; y--)
                    for (int x = SignatureSize - 1; x >= 0; x--)
                    {
                        int i = y * SignatureSize + x; float d = distance[i];
                        if (x < SignatureSize - 1) d = Math.Min(d, distance[i + 1] + 1f);
                        if (y < SignatureSize - 1) d = Math.Min(d, distance[i + SignatureSize] + 1f);
                        if (x < SignatureSize - 1 && y < SignatureSize - 1) d = Math.Min(d, distance[i + SignatureSize + 1] + diagonal);
                        if (x > 0 && y < SignatureSize - 1) d = Math.Min(d, distance[i + SignatureSize - 1] + diagonal);
                        distance[i] = d;
                    }
                return distance;
            }
        }

        private void CropCanvas_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (InputImage.Source == null) return;
            _isCropping = true;
            _cropStart = e.GetPosition(CropCanvas);
            CropRectangle.Visibility = Visibility.Visible;
            Canvas.SetLeft(CropRectangle, _cropStart.X);
            Canvas.SetTop(CropRectangle, _cropStart.Y);
            CropRectangle.Width = 0;
            CropRectangle.Height = 0;
            CropCanvas.CaptureMouse();
        }

        private void CropCanvas_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (!_isCropping) return;
            var p = e.GetPosition(CropCanvas);
            double left = Math.Min(_cropStart.X, p.X), top = Math.Min(_cropStart.Y, p.Y);
            Canvas.SetLeft(CropRectangle, left); Canvas.SetTop(CropRectangle, top);
            CropRectangle.Width = Math.Abs(p.X - _cropStart.X);
            CropRectangle.Height = Math.Abs(p.Y - _cropStart.Y);
        }

        private void CropCanvas_MouseLeftButtonUp(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (!_isCropping) return;
            _isCropping = false; CropCanvas.ReleaseMouseCapture();
            double left = Canvas.GetLeft(CropRectangle), top = Canvas.GetTop(CropRectangle);
            double width = CropRectangle.Width, height = CropRectangle.Height;
            if (width < 8 || height < 8)
            {
                _hasCrop = false; CropRectangle.Visibility = Visibility.Collapsed;
                StatusText.Text = "Crop selection too small. Drag a larger rectangle around the text.";
                return;
            }
            var bitmap = InputImage.Source as BitmapSource;
            if (bitmap == null || CropCanvas.ActualWidth <= 0 || CropCanvas.ActualHeight <= 0) return;
            double scale = Math.Min(CropCanvas.ActualWidth / bitmap.PixelWidth, CropCanvas.ActualHeight / bitmap.PixelHeight);
            double shownW = bitmap.PixelWidth * scale, shownH = bitmap.PixelHeight * scale;
            double offsetX = (CropCanvas.ActualWidth - shownW) / 2.0;
            double offsetY = (CropCanvas.ActualHeight - shownH) / 2.0;
            double ix = Math.Max(0, (left - offsetX) / scale);
            double iy = Math.Max(0, (top - offsetY) / scale);
            double iw = Math.Min(bitmap.PixelWidth - ix, width / scale);
            double ih = Math.Min(bitmap.PixelHeight - iy, height / scale);
            if (iw > 2 && ih > 2)
            {
                _cropX = ix; _cropY = iy; _cropWidth = iw; _cropHeight = ih; _hasCrop = true;
                UpdateCropPreview();
                StatusText.Text = "Crop selected. Find similar fonts will compare only this area.";
            }
        }

        private void ClearCrop_Click(object sender, RoutedEventArgs e)
        {
            _hasCrop = false; CropRectangle.Visibility = Visibility.Collapsed; CropPreviewImage.Source = null;
            StatusText.Text = "Crop cleared. The full image will be compared.";
        }

        private void UpdateCropPreview()
        {
            var bitmap = InputImage.Source as BitmapSource;
            if (bitmap == null || !_hasCrop) { CropPreviewImage.Source = null; return; }
            int x = Math.Max(0, Math.Min(bitmap.PixelWidth - 1, (int)Math.Round(_cropX)));
            int y = Math.Max(0, Math.Min(bitmap.PixelHeight - 1, (int)Math.Round(_cropY)));
            int w = Math.Max(1, Math.Min(bitmap.PixelWidth - x, (int)Math.Round(_cropWidth)));
            int h = Math.Max(1, Math.Min(bitmap.PixelHeight - y, (int)Math.Round(_cropHeight)));
            var crop = new CroppedBitmap(bitmap, new Int32Rect(x, y, w, h));
            double scale = Math.Min(1.0, (double)ProcessingMaxSide / Math.Max(w, h));
            CropPreviewImage.Source = new TransformedBitmap(crop, new System.Windows.Media.ScaleTransform(scale, scale));
        }

        private void ClearSearchCache_Click(object sender, RoutedEventArgs e)
        {
            _searchResultsCache.Clear();
            StatusText.Text = "Search results cache cleared. Reusable font samples were kept.";
        }

        private void FontsGrid_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            UpdateLivePreview();
        }

        private void FontsGrid_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Down || e.Key == System.Windows.Input.Key.Up)
            {
                // DataGrid handles row navigation; selection change refreshes the preview.
                e.Handled = false;
            }
        }

        private void PreviewZoom_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (PreviewTextBlock == null) return;
            PreviewTextBlock.FontSize = e.NewValue;
            if (PreviewZoomLabel != null) PreviewZoomLabel.Text = ((int)e.NewValue).ToString() + " px";
        }

        private void UpdateLivePreview()
        {
            if (PreviewTextBlock == null || FontsGrid == null) return;
            var selected = FontsGrid.SelectedItem as FontRow;
            string text = SampleTextBox == null ? "" : (SampleTextBox.Text ?? "");
            if (selected == null)
            {
                PreviewFontName.Text = "No font selected";
                PreviewTextBlock.Text = string.IsNullOrWhiteSpace(text) ? "Select a result to preview it here." : text;
                PreviewTextBlock.FontFamily = new System.Windows.Media.FontFamily("Segoe UI");
                return;
            }
            PreviewFontName.Text = selected.Family + " — " + selected.Similarity;
            PreviewTextBlock.Text = text;
            PreviewTextBlock.FontFamily = new System.Windows.Media.FontFamily(selected.Family);
            PreviewTextBlock.FontSize = PreviewZoom == null ? 42 : PreviewZoom.Value;
        }

        private void RenderPreview_Click(object sender, RoutedEventArgs e)
        {
            UpdateLivePreview();
            StatusText.Text = "Live preview updated. Use the Up/Down arrow keys to browse fonts.";
        }

        private class FontRow
        {
            public string Family { get; set; }
            public string Style { get; set; }
            public string Similarity { get; set; }
            public double Score { get; set; }
        }
    }
}
