using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Linq;
using System.Windows;
using System.Windows.Media.Imaging;

namespace FontFinder
{
    public partial class MainWindow : Window
    {
        private string _imagePath;
        private List<FontRow> _fontRows = new List<FontRow>();
        private const int Size = 48;

        public MainWindow() { InitializeComponent(); }

        private void ChooseImage_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog { Title = "Choose an image", Filter = "Image files|*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.tif;*.tiff|All files|*.*" };
            if (dialog.ShowDialog() == true)
            {
                try
                {
                    var image = new BitmapImage();
                    image.BeginInit(); image.CacheOption = BitmapCacheOption.OnLoad; image.UriSource = new Uri(dialog.FileName); image.EndInit();
                    InputImage.Source = image; _imagePath = dialog.FileName; ImagePathText.Text = dialog.FileName;
                    StatusText.Text = "Image loaded. Enter its visible text, then click Find similar fonts.";
                }
                catch (Exception ex) { MessageBox.Show("Could not load image: " + ex.Message, "Font Finder", MessageBoxButton.OK, MessageBoxImage.Error); }
            }
        }

        private void ClearImage_Click(object sender, RoutedEventArgs e)
        {
            InputImage.Source = null; _imagePath = null; ImagePathText.Text = "No image selected"; StatusText.Text = "Image cleared.";
        }

        private void ScanFonts_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var fonts = new InstalledFontCollection())
                {
                    _fontRows = fonts.Families.Select(f => new FontRow { Family = f.Name, Style = "Installed", Similarity = "" })
                        .OrderBy(f => f.Family, StringComparer.CurrentCultureIgnoreCase).ToList();
                    FontsGrid.ItemsSource = null; FontsGrid.ItemsSource = _fontRows;
                    if (_fontRows.Count > 0) FontsGrid.SelectedIndex = 0;
                    UpdateLivePreview();
                    StatusText.Text = _fontRows.Count + " installed font families found.";
                }
            }
            catch (Exception ex) { StatusText.Text = "Font scan failed: " + ex.Message; }
        }

        private void FindSimilar_Click(object sender, RoutedEventArgs e)
        {
            if (InputImage.Source == null || string.IsNullOrWhiteSpace(_imagePath))
            { StatusText.Text = "First choose an image."; return; }
            string sample = SampleTextBox.Text ?? "";
            if (string.IsNullOrWhiteSpace(sample)) { StatusText.Text = "Enter the text visible in the image."; return; }
            if (_fontRows.Count == 0) ScanFonts_Click(sender, e);
            try
            {
                StatusText.Text = "Comparing image with installed fonts...";
                var target = MakeImageSignature(_imagePath);
                var scored = new List<FontRow>();
                foreach (var row in _fontRows)
                {
                    try
                    {
                        var candidate = MakeFontSignature(row.Family, sample);
                        double distance = 0;
                        for (int i = 0; i < target.Length; i++) distance += Math.Abs(target[i] - candidate[i]);
                        double similarity = Math.Max(0, 100.0 * (1.0 - distance / target.Length));
                        scored.Add(new FontRow { Family = row.Family, Style = row.Style, Score = similarity, Similarity = similarity.ToString("0.0") + "%" });
                    }
                    catch { }
                }
                var best = scored.OrderByDescending(x => x.Score).Take(20).ToList();
                FontsGrid.ItemsSource = best;
                if (best.Count > 0) FontsGrid.SelectedIndex = 0;
                UpdateLivePreview();
                StatusText.Text = "Compared " + scored.Count + " fonts. Showing up to 20 closest visual matches. Treat scores as approximate.";
            }
            catch (Exception ex) { StatusText.Text = "Comparison failed: " + ex.Message; }
        }

        private static byte[] MakeImageSignature(string path)
        {
            using (var original = new Bitmap(path))
            using (var bmp = new Bitmap(320, 180))
            using (var g = Graphics.FromImage(bmp))
            {
                g.Clear(Color.White); g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                double scale = Math.Min(300.0 / original.Width, 160.0 / original.Height);
                int w = Math.Max(1, (int)(original.Width * scale)), h = Math.Max(1, (int)(original.Height * scale));
                g.DrawImage(original, (320-w)/2, (180-h)/2, w, h);
                return Normalize(bmp);
            }
        }

        private static byte[] MakeFontSignature(string family, string text)
        {
            using (var bmp = new Bitmap(320, 180))
            using (var g = Graphics.FromImage(bmp))
            using (var font = new System.Drawing.Font(family, 54, System.Drawing.FontStyle.Regular, GraphicsUnit.Pixel))
            {
                g.Clear(Color.White); g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
                var rect = new RectangleF(8, 8, 304, 164);
                using (var brush = new SolidBrush(Color.Black))
                using (var format = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center, FormatFlags = StringFormatFlags.NoClip | (text.Any(ch => ch >= 0x0600 && ch <= 0x06FF) ? StringFormatFlags.DirectionRightToLeft : 0) })
                    g.DrawString(text, font, brush, rect, format);
                return Normalize(bmp);
            }
        }

        private static byte[] Normalize(Bitmap source)
        {
            int minX = source.Width, minY = source.Height, maxX = -1, maxY = -1;
            bool[,] ink = new bool[source.Width, source.Height];
            for (int y=0; y<source.Height; y++) for (int x=0; x<source.Width; x++)
            {
                Color c = source.GetPixel(x,y);
                bool dark = (c.R*299 + c.G*587 + c.B*114)/1000 < 190;
                ink[x,y] = dark;
                if (dark) { if(x<minX)minX=x; if(x>maxX)maxX=x; if(y<minY)minY=y; if(y>maxY)maxY=y; }
            }
            var result = new byte[Size*Size];
            if (maxX < minX || maxY < minY) return result;
            int bw=maxX-minX+1, bh=maxY-minY+1;
            double scale=Math.Min((Size-4.0)/bw,(Size-4.0)/bh);
            int dw=Math.Max(1,(int)(bw*scale)), dh=Math.Max(1,(int)(bh*scale));
            int ox=(Size-dw)/2, oy=(Size-dh)/2;
            for(int y=0;y<dh;y++) for(int x=0;x<dw;x++)
            {
                int sx=minX+Math.Min(bw-1,(int)(x/scale)), sy=minY+Math.Min(bh-1,(int)(y/scale));
                result[(oy+y)*Size+ox+x]=ink[sx,sy]?(byte)255:(byte)0;
            }
            return result;
        }

        private void FontsGrid_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            UpdateLivePreview();
        }

        private void FontsGrid_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Down || e.Key == System.Windows.Input.Key.Up)
            {
                // DataGrid handles row navigation; selection change refreshes the preview.
                e.Handled = false;
            }
        }

        private void PreviewZoom_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (PreviewTextBlock == null) return;
            PreviewTextBlock.FontSize = e.NewValue;
            if (PreviewZoomLabel != null) PreviewZoomLabel.Text = ((int)e.NewValue).ToString() + " px";
        }

        private void UpdateLivePreview()
        {
            if (PreviewTextBlock == null || FontsGrid == null) return;
            var selected = FontsGrid.SelectedItem as FontRow;
            string text = SampleTextBox == null ? "" : (SampleTextBox.Text ?? "");
            if (selected == null)
            {
                PreviewFontName.Text = "No font selected";
                PreviewTextBlock.Text = string.IsNullOrWhiteSpace(text) ? "Select a result to preview it here." : text;
                PreviewTextBlock.FontFamily = new System.Windows.Media.FontFamily("Segoe UI");
                return;
            }
            PreviewFontName.Text = selected.Family + " — " + selected.Similarity;
            PreviewTextBlock.Text = text;
            PreviewTextBlock.FontFamily = new System.Windows.Media.FontFamily(selected.Family);
            PreviewTextBlock.FontSize = PreviewZoom == null ? 42 : PreviewZoom.Value;
        }

        private void RenderPreview_Click(object sender, RoutedEventArgs e)
        {
            UpdateLivePreview();
            StatusText.Text = "Live preview updated. Use the Up/Down arrow keys to browse fonts.";
        }

        private class FontRow
        {
            public string Family { get; set; }
            public string Style { get; set; }
            public string Similarity { get; set; }
            public double Score { get; set; }
        }
    }
}
