using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Drawing.Text;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace FontFinder
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ChooseImage_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Title = "Choose an image",
                Filter = "Image files|*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.tif;*.tiff|All files|*.*"
            };
            if (dialog.ShowDialog() == true)
            {
                try
                {
                    var image = new BitmapImage();
                    image.BeginInit();
                    image.CacheOption = BitmapCacheOption.OnLoad;
                    image.UriSource = new Uri(dialog.FileName);
                    image.EndInit();
                    InputImage.Source = image;
                    ImagePathText.Text = dialog.FileName;
                    StatusText.Text = "Image loaded. Enter the visible text if known, then scan fonts.";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Could not load image: " + ex.Message, "Font Finder",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void ClearImage_Click(object sender, RoutedEventArgs e)
        {
            InputImage.Source = null;
            ImagePathText.Text = "No image selected";
            StatusText.Text = "Image cleared.";
        }

        private void ScanFonts_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var fonts = new InstalledFontCollection())
                {
                    var rows = fonts.Families
                        .Select(f => new FontRow { Family = f.Name, Style = "Installed" })
                        .OrderBy(f => f.Family, StringComparer.CurrentCultureIgnoreCase)
                        .ToList();
                    FontsGrid.ItemsSource = rows;
                    StatusText.Text = rows.Count + " installed font families found.";
                }
            }
            catch (Exception ex)
            {
                StatusText.Text = "Font scan failed: " + ex.Message;
            }
        }

        private void RenderPreview_Click(object sender, RoutedEventArgs e)
        {
            var text = SampleTextBox.Text ?? "";
            if (string.IsNullOrWhiteSpace(text))
            {
                StatusText.Text = "Enter sample text first.";
                return;
            }

            var family = FontsGrid.SelectedItem as FontRow;
            var chosen = family == null ? "Segoe UI" : family.Family;
            var preview = new Window
            {
                Title = "Font preview — " + chosen,
                Width = 760,
                Height = 260,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = this,
                Content = new System.Windows.Controls.TextBlock
                {
                    Text = text,
                    FontFamily = new FontFamily(chosen),
                    FontSize = 34,
                    TextWrapping = TextWrapping.Wrap,
                    VerticalAlignment = VerticalAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    Margin = new Thickness(24)
                }
            };
            preview.ShowDialog();
            StatusText.Text = "Preview rendered using " + chosen + ".";
        }

        private class FontRow
        {
            public string Family { get; set; }
            public string Style { get; set; }
        }
    }
}
