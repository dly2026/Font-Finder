﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Text.RegularExpressions;

namespace FontFinder
{
    /// <summary>
    /// Picks a usable style for a family: Regular first, then Bold, Italic, Bold Italic.
    /// </summary>
    internal static class FontStylePicker
    {
        private static readonly FontStyle[] Order =
        {
            FontStyle.Regular,
            FontStyle.Bold,
            FontStyle.Italic,
            FontStyle.Bold | FontStyle.Italic
        };

        public static bool TryPick(FontFamily family, out FontStyle style)
        {
            foreach (FontStyle candidate in Order)
            {
                if (family.IsStyleAvailable(candidate))
                {
                    style = candidate;
                    return true;
                }
            }
            style = FontStyle.Regular;
            return false;
        }

        public static string Label(FontStyle style)
        {
            switch (style)
            {
                case FontStyle.Bold: return "Bold";
                case FontStyle.Italic: return "Italic";
                case FontStyle.Bold | FontStyle.Italic: return "Bold Italic";
                default: return "Regular";
            }
        }
    }

    /// <summary>
    /// Conservative, descriptive classification. When the evidence is not clear the result is Unknown.
    /// Name rules cover well-known families; monospace is verified by measuring glyph advance widths.
    /// </summary>
    internal static class FontClassifier
    {
        private static readonly string[] SymbolTokens =
        {
            "wingdings", "webdings", "symbol", "marlett", "dingbats", "emoji", "mdl2", "icons",
            "holomdl", "sorts", "ornament", "bookshelf"
        };

        private static readonly string[] BitmapTokens =
        {
            "terminal", "fixedsys", "small fonts", "ms sans serif", "ms serif", "pixel", "bitmap", "8bit", "8-bit"
        };

        private static readonly string[] ScriptTokens =
        {
            "script", "handwrit", "brush", "calligraph", "cursive", "corsiva", "edwardian", "vivaldi",
            "kunstler", "freestyle", "mistral", "bradley hand", "ink free", "segoe print", "pristina", "zapfino"
        };

        private static readonly string[] DisplayTokens =
        {
            "display", "decorative", "poster", "stencil", "impact", "jokerman", "chiller", "ravie",
            "broadway", "algerian", "bauhaus", "playbill", "showcard", "snap itc", "magneto", "curlz",
            "gigi", "kristen", "papyrus", "old english", "blackletter", "wide latin", "matura",
            "harrington", "juice itc", "onyx", "bernard mt", "engravers", "felix titling", "colonna"
        };

        private static readonly string[] MonoTokens =
        {
            "courier", "consolas", "monospace", "typewriter", "lucida console", "cascadia", "fira code", "source code", "menlo"
        };

        private static readonly string[] SansNames =
        {
            "arial", "calibri", "candara", "corbel", "segoe", "tahoma", "verdana", "helvetica", "trebuchet",
            "century gothic", "franklin gothic", "myriad", "frutiger", "futura", "avenir", "roboto", "ubuntu",
            "vazir", "iransans", "iranyekan", "samim", "shabnam", "sahel", "leelawadee", "nirmala", "microsoft sans"
        };

        private static readonly string[] SerifNames =
        {
            "times", "georgia", "palatino", "garamond", "book antiqua", "bookman", "cambria", "constantia",
            "century schoolbook", "baskerville", "didot", "bodoni", "minion", "caslon", "rockwell", "sylfaen",
            "lucida bright", "perpetua", "goudy", "footlight", "bell mt", "californian", "calisto"
        };

        private static readonly Regex MonoWord = new Regex(@"\bmono\b", RegexOptions.Compiled);

        /// <summary>Name-only classification (no GDI+). Returns Unknown when no rule applies.</summary>
        public static FontCategory ClassifyByName(string familyName)
        {
            if (string.IsNullOrWhiteSpace(familyName)) return FontCategory.Unknown;
            string lower = familyName.ToLowerInvariant();

            if (ContainsAny(lower, SymbolTokens)) return FontCategory.Symbol;
            if (ContainsAny(lower, BitmapTokens)) return FontCategory.Bitmap;
            if (ContainsAny(lower, ScriptTokens)) return FontCategory.Script;
            if (ContainsAny(lower, DisplayTokens)) return FontCategory.Display;
            if (ContainsAny(lower, MonoTokens) || MonoWord.IsMatch(lower)) return FontCategory.Monospaced;
            if (lower.Contains("slab")) return FontCategory.Serif;
            if (lower.Contains("sans")) return FontCategory.SansSerif;
            if (lower.Contains("serif")) return FontCategory.Serif;
            if (ContainsAny(lower, SansNames)) return FontCategory.SansSerif;
            if (ContainsAny(lower, SerifNames)) return FontCategory.Serif;
            return FontCategory.Unknown;
        }

        /// <summary>Full classification: name rules first, then a monospace measurement.</summary>
        public static FontCategory Classify(string familyName)
        {
            FontCategory byName = ClassifyByName(familyName);
            if (byName != FontCategory.Unknown) return byName;
            return IsMonospaced(familyName) ? FontCategory.Monospaced : FontCategory.Unknown;
        }

        private static bool ContainsAny(string lower, string[] tokens)
        {
            foreach (string token in tokens)
            {
                if (lower.Contains(token)) return true;
            }
            return false;
        }

        private static bool IsMonospaced(string familyName)
        {
            try
            {
                using (var family = new FontFamily(familyName))
                {
                    FontStyle style;
                    if (!FontStylePicker.TryPick(family, out style)) return false;
                    using (var bitmap = new Bitmap(1, 1))
                    using (var graphics = Graphics.FromImage(bitmap))
                    using (var font = new Font(family, 40f, style, GraphicsUnit.Pixel))
                    using (var format = new StringFormat(StringFormat.GenericTypographic))
                    {
                        float narrow = graphics.MeasureString("iiiiiiiiii", font, PointF.Empty, format).Width;
                        float wide = graphics.MeasureString("WWWWWWWWWW", font, PointF.Empty, format).Width;
                        float digits = graphics.MeasureString("0000000000", font, PointF.Empty, format).Width;
                        if (narrow <= 0f || wide <= 0f || digits <= 0f) return false;
                        return Math.Abs(narrow - wide) / wide < 0.02f && Math.Abs(digits - wide) / wide < 0.02f;
                    }
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine("FontFinder: classification measurement failed for '" + familyName + "': " + ex.Message);
                return false;
            }
        }
    }
}
