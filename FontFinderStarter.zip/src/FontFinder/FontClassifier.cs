﻿
using System;
using System.Diagnostics;
using System.Drawing;
using System.Text.RegularExpressions;

namespace FontFinder
{
    /// <summary>
    /// Picks a usable style for a family: Regular first, then Bold, Italic, Bold Italic.
    /// </summary>
    internal static class FontStylePicker
    {
        private static readonly FontStyle[] Order =
        {
            FontStyle.Regular,
            FontStyle.Bold,
            FontStyle.Italic,
            FontStyle.Bold | FontStyle.Italic
        };

        public static bool TryPick(FontFamily family, out FontStyle style)
        {
            foreach (FontStyle candidate in Order)
            {
                if (family.IsStyleAvailable(candidate))
                {
                    style = candidate;
                    return true;
                }
            }

            style = FontStyle.Regular;
            return false;
        }

        public static string Label(FontStyle style)
        {
            switch (style)
            {
                case FontStyle.Bold: return "Bold";
                case FontStyle.Italic: return "Italic";
                case FontStyle.Bold | FontStyle.Italic: return "Bold Italic";
                default: return "Regular";
            }
        }
    }

    /// <summary>
    /// Descriptive font classification.
    /// Uses family-name clues first and actual glyph measurements for monospace fallback.
    /// </summary>
    internal static class FontClassifier
    {
        private static readonly string[] SymbolTokens =
        {
            "wingdings", "webdings", "symbol", "marlett", "dingbats",
            "emoji", "mdl2", "mdl2 assets", "holomdl", "icons",
            "ornament", "bookshelf", "pictogram"
        };

        private static readonly string[] PixelTokens =
        {
            "pixel", "bitmap", "8bit", "8-bit", "16bit", "16-bit",
            "arcade", "dot matrix", "dotmatrix", "digital clock",
            "lcd", "led", "raster display"
        };

        private static readonly string[] BlackletterTokens =
        {
            "blackletter", "textura", "fraktur", "schwabacher",
            "rotunda", "bastarda", "old english", "gothic text"
        };

        private static readonly string[] ScriptTokens =
        {
            "script", "brush", "calligraph", "copperplate",
            "roundhand", "spencerian", "engraver", "wedding",
            "signature", "chancery", "corsiva", "edwardian",
            "vivaldi", "kunstler", "freestyle", "mistral",
            "magneto", "zapfino", "bickham", "snell roundhand"
        };

        private static readonly string[] HandwritingTokens =
        {
            "handwrit", "hand written", "hand-written",
            "bradley hand", "ink free", "segoe print",
            "comic sans", "marker", "chalk", "pencil handwriting"
        };

        private static readonly string[] DisplayTokens =
        {
            "display", "decorative", "poster", "headline",
            "impact", "jokerman", "chiller", "ravie",
            "broadway", "algerian", "bauhaus", "playbill",
            "showcard", "snap itc", "curlz", "gigi",
            "kristen", "papyrus", "wide latin", "matura",
            "harrington", "juice itc", "onyx", "bernard mt",
            "felix titling", "colonna", "circus", "carnival",
            "horror", "western", "art deco", "art nouveau",
            "stencil", "graffiti", "psychedelic", "bubble",
            "comic", "cartoon", "neon", "glitch", "tattoo",
            "victorian", "ornamental", "novelty"
        };

        private static readonly string[] MonoTokens =
        {
            "courier", "consolas", "monospace", "typewriter",
            "lucida console", "cascadia", "fira code",
            "source code", "menlo", "mono", "terminal",
            "fixedsys", "ocr"
        };

        private static readonly string[] SansNames =
        {
            "arial", "calibri", "candara", "corbel", "segoe",
            "tahoma", "verdana", "helvetica", "trebuchet",
            "century gothic", "franklin gothic", "myriad",
            "frutiger", "futura", "avenir", "roboto", "ubuntu",
            "vazir", "iransans", "iranyekan", "samim",
            "shabnam", "sahel", "leelawadee", "nirmala",
            "microsoft sans", "open sans", "lato", "montserrat",
            "poppins", "nunito", "raleway", "inter",
            "source sans", "work sans", "manrope"
        };

        private static readonly string[] SerifNames =
        {
            "times", "georgia", "palatino", "garamond",
            "book antiqua", "bookman", "cambria", "constantia",
            "century schoolbook", "baskerville", "didot",
            "bodoni", "minion", "caslon", "rockwell",
            "sylfaen", "lucida bright", "perpetua", "goudy",
            "footlight", "bell mt", "californian", "calisto",
            "baskerville", "merriweather", "playfair",
            "libre baskerville", "source serif", "lora",
            "bitter", "pt serif", "spectral", "roboto slab"
        };

        private static readonly Regex MonoWord =
            new Regex(@"\bmono\b", RegexOptions.Compiled);

        public static FontCategory ClassifyByName(string familyName)
        {
            if (string.IsNullOrWhiteSpace(familyName))
                return FontCategory.Unknown;

            string name = familyName.ToLowerInvariant();

            // Symbols and special-purpose fonts
            if (ContainsAny(name, SymbolTokens))
                return FontCategory.Symbol;

            // Pixel and bitmap fonts
            if (ContainsAny(name, PixelTokens))
                return FontCategory.Pixel;

            // Blackletter
            if (ContainsAny(name, BlackletterTokens))
                return FontCategory.Blackletter;

            // Handwriting before general script
            if (ContainsAny(name, HandwritingTokens))
                return FontCategory.Handwriting;

            // Script families
            if (ContainsAny(name, ScriptTokens))
                return FontCategory.Script;

            // Decorative and display styles
            if (ContainsAny(name, DisplayTokens))
                return FontCategory.Display;

            // Monospaced families
            if (ContainsAny(name, MonoTokens) || MonoWord.IsMatch(name))
                return FontCategory.Monospaced;

            // Slab serif names, excluding Roboto Slab.
            if ((name.Contains("slab") &&
                 !name.Contains("roboto slab")) ||
                name.Contains("egyptian") ||
                name.Contains("clarendon") ||
                name.Contains("rockwell"))
                return FontCategory.SlabSerif;

            // Serif subcategories
            if (name.Contains("didone") ||
                name.Contains("didot") ||
                name.Contains("bodoni"))
                return FontCategory.Didone;

            if (name.Contains("garalde") ||
                name.Contains("garamond") ||
                name.Contains("caslon"))
                return FontCategory.GaraldeSerif;

            if (name.Contains("transitional"))
                return FontCategory.TransitionalSerif;

            if (name.Contains("old style") ||
                name.Contains("oldstyle"))
                return FontCategory.OldStyleSerif;

            if (name.Contains("scotch"))
                return FontCategory.ScotchRoman;

            if (name.Contains("wedge"))
                return FontCategory.WedgeSerif;

            if (name.Contains("glyphic") ||
                name.Contains("inscriptional"))
                return FontCategory.GlyphicSerif;

            if (name.Contains("fat face") ||
                name.Contains("fatface"))
                return FontCategory.FatFace;

            if (name.Contains("hairline"))
                return FontCategory.HairlineSerif;

            if (name.Contains("tuscan"))
                return FontCategory.TuscanSerif;

            if (name.Contains("antique"))
                return FontCategory.AntiqueSerif;

            // Known sans families: main category first.
            if (ContainsAny(name, SansNames))
                return FontCategory.SansSerif;

            // Sans serif subcategories
            if (name.Contains("neo grotesque") ||
                name.Contains("neogrotesque") ||
                name.Contains("helvetica") ||
                name.Contains("arial"))
                return FontCategory.NeoGrotesque;

            if (name.Contains("geometric"))
                return FontCategory.GeometricSans;

            if (name.Contains("humanist"))
                return FontCategory.HumanistSans;

            if (name.Contains("rounded"))
                return FontCategory.RoundedSans;

            if (name.Contains("square"))
                return FontCategory.SquareSans;

            if (name.Contains("industrial"))
                return FontCategory.IndustrialSans;

            if (name.Contains("grotesque") ||
                name.Contains("gothic"))
                return FontCategory.Grotesque;

            if (name.Contains("sans"))
                return FontCategory.SansSerif;

            // Remaining serif families
            if (name.Contains("serif") ||
                ContainsAny(name, SerifNames))
                return FontCategory.Serif;

            return FontCategory.Unknown;
        }

        /// <summary>
        /// Full classification: name rules first, then monospace measurement.
        /// </summary>
        public static FontCategory Classify(string familyName)
        {
            FontCategory byName = ClassifyByName(familyName);

            if (byName != FontCategory.Unknown)
                return byName;

            return IsMonospaced(familyName)
                ? FontCategory.Monospaced
                : FontCategory.Unknown;
        }

        private static bool ContainsAny(string value, string[] tokens)
        {
            foreach (string token in tokens)
            {
                if (value.Contains(token))
                    return true;
            }

            return false;
        }

        private static bool IsMonospaced(string familyName)
        {
            try
            {
                using (var family = new FontFamily(familyName))
                {
                    FontStyle style;

                    if (!FontStylePicker.TryPick(family, out style))
                        return false;

                    using (var bitmap = new Bitmap(1, 1))
                    using (var graphics = Graphics.FromImage(bitmap))
                    using (var font = new Font(
                        family, 40f, style, GraphicsUnit.Pixel))
                    using (var format =
                        new StringFormat(StringFormat.GenericTypographic))
                    {
                        float narrow = graphics.MeasureString(
                            "iiiiiiiiii", font, PointF.Empty, format).Width;

                        float wide = graphics.MeasureString(
                            "WWWWWWWWWW", font, PointF.Empty, format).Width;

                        float digits = graphics.MeasureString(
                            "0000000000", font, PointF.Empty, format).Width;

                        if (narrow <= 0f || wide <= 0f || digits <= 0f)
                            return false;

                        return Math.Abs(narrow - wide) / wide < 0.02f &&
                               Math.Abs(digits - wide) / wide < 0.02f;
                    }
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine(
                    "FontFinder: classification measurement failed for '" +
                    familyName + "': " + ex.Message);

                return false;
            }
        }
    }
}
