﻿using System;

namespace FontFinder
{
    /// <summary>
    /// Simple soft ranking: overall form 70%, shape pattern 20%, proportions 10%.
    /// No component can eliminate a font and there is no score threshold.
    /// The weights are heuristic, not validated probabilities.
    /// </summary>
    internal static class ShapeScorer
    {
        public const double SilhouetteWeight = 0.70;
        public const double PatternWeight = 0.20;
        public const double ProportionWeight = 0.10;

        public static double Combined(ShapeSignature target, ShapeSignature candidate)
        {
            return SilhouetteWeight * Silhouette(target, candidate)
                 + PatternWeight * Pattern(target, candidate)
                 + ProportionWeight * Proportions(target, candidate);
        }

        /// <summary>Overall form: symmetric chamfer distance between the two silhouettes.</summary>
        public static double Silhouette(ShapeSignature a, ShapeSignature b)
        {
            double forward = DirectedChamfer(a.Mask, b.DistanceMap);
            double backward = DirectedChamfer(b.Mask, a.DistanceMap);
            double chamfer = (forward + backward) / 2.0;
            double ratioPenalty = Math.Min(8.0,
                Math.Abs(Math.Log(Math.Max(0.01, a.AspectRatio) / Math.Max(0.01, b.AspectRatio))) * 5.0);
            return Math.Max(0.0, Math.Min(100.0, 100.0 * (1.0 - (chamfer + ratioPenalty) / 24.0)));
        }

        /// <summary>Shape pattern: row and column ink projections.</summary>
        public static double Pattern(ShapeSignature a, ShapeSignature b)
        {
            double difference = 0;
            for (int i = 0; i < ShapeSignature.Size; i++)
            {
                difference += Math.Abs(a.RowProjection[i] - b.RowProjection[i])
                            + Math.Abs(a.ColumnProjection[i] - b.ColumnProjection[i]);
            }
            return Math.Max(0, 100.0 - difference * 25.0);
        }

        /// <summary>Proportions: aspect ratio, ink density and visual centre.</summary>
        public static double Proportions(ShapeSignature a, ShapeSignature b)
        {
            double ratio = Math.Abs(Math.Log(Math.Max(0.01, a.AspectRatio) / Math.Max(0.01, b.AspectRatio)));
            double density = Math.Abs(a.InkRatio - b.InkRatio);
            double center = Math.Abs(a.CenterX - b.CenterX) + Math.Abs(a.CenterY - b.CenterY);
            return Math.Max(0, 100.0 - ratio * 22.0 - density * 90.0 - center * 35.0);
        }

        private static double DirectedChamfer(bool[] sourceMask, float[] targetDistance)
        {
            double sum = 0;
            int count = 0;
            for (int i = 0; i < sourceMask.Length; i++)
            {
                if (!sourceMask[i]) continue;
                sum += Math.Min(24.0, targetDistance[i]);
                count++;
            }
            return count == 0 ? 24.0 : sum / count;
        }
    }
}
