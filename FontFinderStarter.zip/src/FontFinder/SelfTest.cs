﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace FontFinder
{
    /// <summary>
    /// Built-in checks run with "FontFinder.exe --selftest [results-file]" (used by the CI workflow).
    /// Exit code 0 = all checks passed (skipped checks do not fail), 1 = at least one check failed.
    /// </summary>
    internal static class SelfTest
    {
        private sealed class SkipException : Exception
        {
            public SkipException(string message) : base(message) { }
        }

        private sealed class Outcome
        {
            public string Name;
            public string Status;
            public string Detail;
        }

        private static readonly List<Outcome> Outcomes = new List<Outcome>();

        public static int Run(string outputPath)
        {
            Outcomes.Clear();
            string workDir = Path.Combine(Path.GetTempPath(), "FontFinderSelfTest-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(workDir);
            try
            {
                Check("Cache: round trip memory -> disk", () => CacheRoundTrip(workDir));
                Check("Cache: truncated file is rebuilt", () => CacheTruncatedFile(workDir));
                Check("Cache: checksum mismatch is rebuilt", () => CacheChecksumMismatch(workDir));
                Check("Cache: writes are atomic (no temp files left)", () => CacheNoTempFiles(workDir));
                Check("Cache: Clear() empties the font cache only", () => CacheClear(workDir));
                Check("Crop: clamped to image edges", CropEdges);
                Check("Crop: rectangle outside the image is rejected", CropOutside);
                Check("Ranking: weights are 70/20/10", ScoreWeights);
                Check("Culture: percentages are culture independent", InvariantPercent);
                Check("Prefilter: 500 selected, extremes kept", ShortlistKeepsExtremes);
                Check("Categories: name rules and Unknown fallback", CategoryRules);
                Check("Search: ranks the source font first, nothing eliminated", () => SearchRanking(workDir));
            }
            finally
            {
                TryDeleteDirectory(workDir);
            }

            int failed = Outcomes.Count(o => o.Status == "FAIL");
            int skipped = Outcomes.Count(o => o.Status == "SKIP");
            var report = new StringBuilder();
            report.AppendLine("Font Finder self-test " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
            report.AppendLine("Culture: " + CultureInfo.CurrentCulture.Name + "   OS: " + Environment.OSVersion);
            report.AppendLine();
            foreach (Outcome o in Outcomes)
                report.AppendLine("[" + o.Status + "] " + o.Name + (string.IsNullOrEmpty(o.Detail) ? string.Empty : "  -  " + o.Detail));
            report.AppendLine();
            report.AppendLine("Passed " + Outcomes.Count(o => o.Status == "PASS") + ", failed " + failed + ", skipped " + skipped + ".");

            string path = string.IsNullOrWhiteSpace(outputPath)
                ? Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "selftest-results.txt")
                : outputPath;
            try
            {
                File.WriteAllText(path, report.ToString(), Encoding.UTF8);
            }
            catch (Exception ex)
            {
                AppLog.Write("Could not write self-test results to " + path + ": " + ex.Message);
            }
            return failed == 0 ? 0 : 1;
        }

        // ------------------------------------------------------------------ framework

        private static void Check(string name, Func<string> test)
        {
            var outcome = new Outcome { Name = name };
            try
            {
                outcome.Detail = test();
                outcome.Status = "PASS";
            }
            catch (SkipException ex)
            {
                outcome.Status = "SKIP";
                outcome.Detail = ex.Message;
            }
            catch (Exception ex)
            {
                outcome.Status = "FAIL";
                outcome.Detail = ex.GetType().Name + ": " + ex.Message;
                AppLog.Write("Self-test failed: " + name + " - " + ex);
            }
            Outcomes.Add(outcome);
        }

        private static void Require(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
        }

        private static void TryDeleteDirectory(string path)
        {
            try
            {
                if (Directory.Exists(path)) Directory.Delete(path, true);
            }
            catch (Exception ex)
            {
                AppLog.Write("Could not remove self-test folder " + path + ": " + ex.Message);
            }
        }

        private static ShapeSignature MakeSignature(int variant)
        {
            var mask = new bool[ShapeSignature.Size * ShapeSignature.Size];
            for (int y = 12; y < 52; y++)
            {
                for (int x = 12; x < 52; x++)
                {
                    bool ink = variant == 0 ? (x < 20 || x > 43 || y < 20) : (x >= 28 && x <= 36);
                    mask[y * ShapeSignature.Size + x] = ink;
                }
            }
            return new ShapeSignature(mask, variant == 0 ? 0.9 : 0.4);
        }

        private static bool SameMask(ShapeSignature a, ShapeSignature b)
        {
            return a.Mask.SequenceEqual(b.Mask) && Math.Abs(a.AspectRatio - b.AspectRatio) < 1e-12;
        }

        private static Func<ShapeSignature> MustNotRender()
        {
            return () => { throw new InvalidOperationException("The signature should have come from the cache."); };
        }

        // ------------------------------------------------------------------ cache

        private static string CacheRoundTrip(string workDir)
        {
            string folder = Path.Combine(workDir, "roundtrip");
            ShapeSignature original = MakeSignature(0);

            var first = new SignatureStore(folder);
            var stats1 = new SearchStats();
            first.GetOrCreate("key-1", () => original, stats1);
            Require(stats1.Generated == 1, "first lookup should render once");

            first.GetOrCreate("key-1", MustNotRender(), stats1);
            Require(stats1.MemoryHits == 1, "second lookup should hit memory");

            var second = new SignatureStore(folder);
            var stats2 = new SearchStats();
            ShapeSignature loaded = second.GetOrCreate("key-1", MustNotRender(), stats2);
            Require(stats2.DiskHits == 1, "a new store should hit the disk cache");
            Require(SameMask(original, loaded), "the reloaded signature differs from the original");
            return "memory hit, disk hit, identical data";
        }

        private static string CacheTruncatedFile(string workDir)
        {
            string folder = Path.Combine(workDir, "truncated");
            ShapeSignature original = MakeSignature(1);
            var store = new SignatureStore(folder);
            store.GetOrCreate("key-2", () => original, new SearchStats());

            File.WriteAllBytes(store.GetPath("key-2"), new byte[] { 1, 2, 3 });

            var fresh = new SignatureStore(folder);
            var stats = new SearchStats();
            ShapeSignature rebuilt = fresh.GetOrCreate("key-2", () => original, stats);
            Require(stats.Generated == 1 && stats.DiskHits == 0, "a corrupt file must be rebuilt, not trusted");
            Require(SameMask(original, rebuilt), "rebuilt signature differs");

            var again = new SignatureStore(folder);
            var statsAgain = new SearchStats();
            again.GetOrCreate("key-2", MustNotRender(), statsAgain);
            Require(statsAgain.DiskHits == 1, "the repaired file should now load from disk");
            return "corrupt file replaced and reusable";
        }

        private static string CacheChecksumMismatch(string workDir)
        {
            string folder = Path.Combine(workDir, "checksum");
            ShapeSignature original = MakeSignature(0);
            var store = new SignatureStore(folder);
            store.GetOrCreate("key-3", () => original, new SearchStats());

            string path = store.GetPath("key-3");
            byte[] bytes = File.ReadAllBytes(path);
            bytes[30] ^= 0xFF; // flip bits inside the packed mask
            File.WriteAllBytes(path, bytes);

            var fresh = new SignatureStore(folder);
            var stats = new SearchStats();
            fresh.GetOrCreate("key-3", () => original, stats);
            Require(stats.Generated == 1 && stats.DiskHits == 0, "a checksum mismatch must trigger a rebuild");
            return "bit flip detected";
        }

        private static string CacheNoTempFiles(string workDir)
        {
            string folder = Path.Combine(workDir, "atomic");
            var store = new SignatureStore(folder);
            for (int i = 0; i < 20; i++)
                store.GetOrCreate("atomic-" + i, () => MakeSignature(i % 2), new SearchStats());

            int temp = Directory.GetFiles(folder, "*.tmp").Length;
            int bins = Directory.GetFiles(folder, "*.bin").Length;
            Require(temp == 0, temp + " temporary file(s) left behind");
            Require(bins == 20, "expected 20 cache files but found " + bins);
            return "20 files, 0 temporary files";
        }

        private static string CacheClear(string workDir)
        {
            string folder = Path.Combine(workDir, "clear");
            var store = new SignatureStore(folder);
            store.GetOrCreate("c1", () => MakeSignature(0), new SearchStats());
            store.GetOrCreate("c2", () => MakeSignature(1), new SearchStats());
            int removed = store.Clear();
            Require(removed == 2, "expected to remove 2 files, removed " + removed);
            Require(Directory.GetFiles(folder, "*.bin").Length == 0, "cache files remain");
            return "removed " + removed + " files";
        }

        // ------------------------------------------------------------------ crop

        private static string CropEdges()
        {
            int x, y, w, h;

            // 400x200 image shown at scale 0.5 with offset (50, 20): displayed area is 200x100.
            Require(CropMath.TryCanvasToImage(30, 10, 100, 60, 0.5, 50, 20, 400, 200, 8, out x, out y, out w, out h),
                "top-left overhang should still produce a crop");
            Require(x == 0 && y == 0 && w == 160 && h == 100, "top-left overhang gave " + x + "," + y + "," + w + "," + h);

            Require(CropMath.TryCanvasToImage(200, 50, 200, 200, 0.5, 50, 20, 400, 200, 8, out x, out y, out w, out h),
                "bottom-right overhang should still produce a crop");
            Require(x == 300 && y == 60 && w == 100 && h == 140, "bottom-right overhang gave " + x + "," + y + "," + w + "," + h);

            int cx, cy, cw, ch;
            Require(CropMath.TryClamp(-10, -10, 50, 50, 100, 100, out cx, out cy, out cw, out ch)
                && cx == 0 && cy == 0 && cw == 40 && ch == 40, "TryClamp did not clip to the image");
            return "overhangs are clipped to the image";
        }

        private static string CropOutside()
        {
            int x, y, w, h;
            Require(!CropMath.TryCanvasToImage(0, 0, 40, 40, 0.5, 50, 20, 400, 200, 8, out x, out y, out w, out h),
                "a rectangle entirely in the letterbox must be rejected");
            Require(!CropMath.TryCanvasToImage(60, 30, 4, 4, 0.5, 50, 20, 400, 200, 8, out x, out y, out w, out h),
                "a tiny rectangle must be rejected");
            int cx, cy, cw, ch;
            Require(!CropMath.TryClamp(500, 500, 10, 10, 100, 100, out cx, out cy, out cw, out ch),
                "TryClamp must reject a rectangle outside the image");
            return "rejected as expected";
        }

        // ------------------------------------------------------------------ ranking

        private static string ScoreWeights()
        {
            Require(Math.Abs(ShapeScorer.SilhouetteWeight + ShapeScorer.PatternWeight + ShapeScorer.ProportionWeight - 1.0) < 1e-9,
                "weights do not sum to 1");
            Require(Math.Abs(ShapeScorer.SilhouetteWeight - 0.70) < 1e-9
                && Math.Abs(ShapeScorer.PatternWeight - 0.20) < 1e-9
                && Math.Abs(ShapeScorer.ProportionWeight - 0.10) < 1e-9, "weights are not 70/20/10");

            ShapeSignature a = MakeSignature(0);
            ShapeSignature b = MakeSignature(1);
            double expected = 0.70 * ShapeScorer.Silhouette(a, b)
                            + 0.20 * ShapeScorer.Pattern(a, b)
                            + 0.10 * ShapeScorer.Proportions(a, b);
            double actual = ShapeScorer.Combined(a, b);
            Require(Math.Abs(expected - actual) < 1e-9, "Combined() is not 0.7*form + 0.2*pattern + 0.1*proportions");
            Require(Math.Abs(ShapeScorer.Combined(a, a) - 100.0) < 1e-6, "identical shapes should score 100");
            Require(actual < 100.0, "different shapes should score below 100");
            return "combined score " + Formatting.Percent(actual);
        }

        private static string InvariantPercent()
        {
            CultureInfo saved = Thread.CurrentThread.CurrentCulture;
            try
            {
                Thread.CurrentThread.CurrentCulture = new CultureInfo("de-DE");
                string text = Formatting.Percent(12.34);
                Require(text == "12.3%", "expected 12.3% but got " + text);
            }
            finally
            {
                Thread.CurrentThread.CurrentCulture = saved;
            }
            return "12.3% under de-DE";
        }

        private static string ShortlistKeepsExtremes()
        {
            var items = new List<CoarseItem>();
            for (int i = 0; i < 1200; i++)
            {
                double logRatio = -2.0 + 4.0 * i / 1199.0;
                items.Add(new CoarseItem(new FontRow { Family = "Font " + i.ToString("0000", CultureInfo.InvariantCulture) }, logRatio));
            }

            List<FontRow> shortlist = FontMatcher.SelectShortlist(items, 500);
            Require(shortlist.Count == 500, "expected 500 families but got " + shortlist.Count);
            Require(shortlist.Select(r => r.Family).Distinct().Count() == 500, "the shortlist contains duplicates");
            Require(shortlist.Any(r => r.Family == "Font 0000"), "the narrowest family was dropped");
            Require(shortlist.Any(r => r.Family == "Font 1199"), "the widest family was dropped");
            Require(shortlist.Any(r => r.Family == "Font 0600" || r.Family == "Font 0599"), "the closest family was dropped");
            return "500 distinct, both extremes present";
        }

        private static string CategoryRules()
        {
            var expected = new Dictionary<string, FontCategory>
            {
                { "Times New Roman", FontCategory.Serif },
                { "Arial", FontCategory.SansSerif },
                { "Roboto Slab", FontCategory.Serif },
                { "Segoe Script", FontCategory.Script },
                { "Impact", FontCategory.Display },
                { "Wingdings", FontCategory.Symbol },
                { "Segoe UI Symbol", FontCategory.Symbol },
                { "Terminal", FontCategory.Bitmap },
                { "Courier New", FontCategory.Monospaced },
                { "DejaVu Sans Mono", FontCategory.Monospaced },
                { "Qwxz Unlisted", FontCategory.Unknown }
            };
            foreach (KeyValuePair<string, FontCategory> pair in expected)
            {
                FontCategory actual = FontClassifier.ClassifyByName(pair.Key);
                Require(actual == pair.Value, pair.Key + ": expected " + pair.Value + " but got " + actual);
            }
            return expected.Count + " name rules verified";
        }

        private static string SearchRanking(string workDir)
        {
            var wanted = new[] { "Arial", "Times New Roman", "Courier New", "Segoe UI", "Verdana", "Georgia", "Calibri" };
            var available = new List<string>();
            using (var installed = new InstalledFontCollection())
            {
                foreach (FontFamily family in installed.Families)
                {
                    if (wanted.Contains(family.Name, StringComparer.OrdinalIgnoreCase)) available.Add(family.Name);
                }
            }
            if (!available.Contains("Arial") || available.Count < 3)
                throw new SkipException("needs Arial plus at least two other common fonts; found " + string.Join(", ", available));

            // Build the "image" from Arial's own glyph so the expected winner is known.
            string imagePath = Path.Combine(workDir, "target.png");
            using (var family = new FontFamily("Arial"))
            {
                FontStyle style;
                Require(FontStylePicker.TryPick(family, out style), "Arial has no usable style");
                using (Bitmap bitmap = GlyphRenderer.Render(family, style, "A", 256, 256, 180f))
                    bitmap.Save(imagePath, ImageFormat.Png);
            }

            var fonts = available.Select(n => new FontRow { Family = n, Category = FontClassifier.Classify(n).Label() }).ToList();
            fonts.Add(new FontRow { Family = "No Such Font 12345", Category = "Unknown" });

            var store = new SignatureStore(Path.Combine(workDir, "search-cache"));
            var request = new SearchRequest
            {
                ImagePath = imagePath,
                Text = "A",
                Fonts = fonts,
                Store = store
            };

            SearchOutcome first = FontMatcher.Search(request, null);
            Require(first.Failed == 1, "the missing font should be reported once, got " + first.Failed);
            Require(first.Rows.Count == available.Count, "every usable font must be scored (" + first.Rows.Count + " of " + available.Count + ")");
            Require(first.Rows.Count <= 100, "more than 100 results returned");
            Require(first.Rows[0].Family.Equals("Arial", StringComparison.OrdinalIgnoreCase),
                "expected Arial first but got " + first.Rows[0].Family);
            for (int i = 1; i < first.Rows.Count; i++)
                Require(first.Rows[i - 1].Score >= first.Rows[i].Score, "results are not sorted by score");
            Require(first.Rows.All(r => !string.IsNullOrEmpty(r.Category)), "a result is missing its category");

            // Same glyph again, with surrounding spaces and a different (unrelated) text box value:
            // the font cache is keyed by font + glyph, so nothing is rendered a second time.
            request.Text = "  A ";
            SearchOutcome second = FontMatcher.Search(request, null);
            Require(second.Generated == 0, "the second search rendered " + second.Generated + " glyph(s) again");
            Require(second.MemoryHits >= available.Count, "the second search should hit the cache for every font");

            // Restart simulation: a new store on the same folder must serve everything from disk.
            request.Store = new SignatureStore(store.Folder);
            SearchOutcome third = FontMatcher.Search(request, null);
            Require(third.Generated == 0 && third.DiskHits >= available.Count, "the disk cache was not reused");

            return "top = " + first.Rows[0].Family + " " + first.Rows[0].Similarity + ", " + first.Rows.Count
                + " scored, 1 skipped (reported), cache reused";
        }
    }
}
