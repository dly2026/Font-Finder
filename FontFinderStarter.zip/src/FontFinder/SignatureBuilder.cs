﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace FontFinder
{
    /// <summary>Turns a crop of the input image or a rendered font sample into a ShapeSignature.</summary>
    internal static class SignatureBuilder
    {
        public const int ProcessingMaxSide = 256;
        private const double MaxUpscale = 4.0;
        private const double CoverageThreshold = 0.35;

        public static ShapeSignature FromImageFile(string path, bool hasCrop, int cropX, int cropY, int cropWidth, int cropHeight)
        {
            using (var original = new Bitmap(path))
            {
                Rectangle source = new Rectangle(0, 0, original.Width, original.Height);
                if (hasCrop)
                {
                    int x, y, w, h;
                    if (!CropMath.TryClamp(cropX, cropY, cropWidth, cropHeight, original.Width, original.Height,
                            out x, out y, out w, out h))
                        throw new InvalidOperationException("The crop rectangle is outside the image.");
                    source = new Rectangle(x, y, w, h);
                }

                double factor = Math.Min(MaxUpscale, (double)ProcessingMaxSide / Math.Max(source.Width, source.Height));
                int targetW = Math.Max(1, (int)Math.Round(source.Width * factor));
                int targetH = Math.Max(1, (int)Math.Round(source.Height * factor));

                using (var work = new Bitmap(targetW, targetH, PixelFormat.Format32bppArgb))
                using (var graphics = Graphics.FromImage(work))
                using (var attributes = new ImageAttributes())
                {
                    // Tile-flip avoids a halo from pixels outside the crop at its edges.
                    attributes.SetWrapMode(WrapMode.TileFlipXY);
                    graphics.Clear(Color.White);
                    graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
                    graphics.DrawImage(original, new Rectangle(0, 0, targetW, targetH),
                        source.X, source.Y, source.Width, source.Height, GraphicsUnit.Pixel, attributes);
                    return FromBitmap(work, true);
                }
            }
        }

        /// <summary>
        /// Builds a signature from an opaque bitmap. With autoPolarity the background is detected from the
        /// border (light-on-dark images work); otherwise dark ink on a light background is assumed.
        /// </summary>
        public static ShapeSignature FromBitmap(Bitmap source, bool autoPolarity)
        {
            int width = source.Width;
            int height = source.Height;
            var gray = new byte[width * height];
            int ring = Math.Max(1, Math.Min(width, height) / 50);
            long borderSum = 0;
            long borderCount = 0;

            BitmapData data = source.LockBits(new Rectangle(0, 0, width, height),
                ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            try
            {
                int stride = data.Stride;
                int rowLength = Math.Abs(stride);
                var row = new byte[rowLength];
                for (int y = 0; y < height; y++)
                {
                    Marshal.Copy(IntPtr.Add(data.Scan0, y * stride), row, 0, rowLength);
                    for (int x = 0; x < width; x++)
                    {
                        int index = x * 4;
                        byte value = (byte)((row[index + 2] * 299 + row[index + 1] * 587 + row[index] * 114) / 1000);
                        gray[y * width + x] = value;
                        if (x < ring || y < ring || x >= width - ring || y >= height - ring)
                        {
                            borderSum += value;
                            borderCount++;
                        }
                    }
                }
            }
            finally
            {
                source.UnlockBits(data);
            }

            int threshold = Math.Max(40, Math.Min(215, OtsuThreshold(gray)));
            bool lightBackground = true;
            if (autoPolarity && borderCount > 0)
                lightBackground = (double)borderSum / borderCount > threshold;

            var raw = new bool[width * height];
            int minX = width, minY = height, maxX = -1, maxY = -1;
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    int value = gray[y * width + x];
                    bool ink = lightBackground ? value <= threshold : value > threshold;
                    raw[y * width + x] = ink;
                    if (!ink) continue;
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }

            var mask = new bool[ShapeSignature.Size * ShapeSignature.Size];
            if (maxX < minX || maxY < minY) return new ShapeSignature(mask, 1.0);

            int boxW = maxX - minX + 1;
            int boxH = maxY - minY + 1;
            double aspect = (double)boxW / boxH;
            double scale = Math.Min((ShapeSignature.Size - 8.0) / boxW, (ShapeSignature.Size - 8.0) / boxH);
            int destW = Math.Max(1, (int)Math.Round(boxW * scale));
            int destH = Math.Max(1, (int)Math.Round(boxH * scale));
            int offsetX = (ShapeSignature.Size - destW) / 2;
            int offsetY = (ShapeSignature.Size - destH) / 2;

            // Area sampling keeps thin strokes when a large glyph is reduced to 64x64.
            for (int dy = 0; dy < destH; dy++)
            {
                int y0 = Math.Min(maxY, minY + (int)Math.Floor(dy / scale));
                int y1 = Math.Max(y0 + 1, Math.Min(maxY + 1, minY + (int)Math.Ceiling((dy + 1) / scale)));
                for (int dx = 0; dx < destW; dx++)
                {
                    int x0 = Math.Min(maxX, minX + (int)Math.Floor(dx / scale));
                    int x1 = Math.Max(x0 + 1, Math.Min(maxX + 1, minX + (int)Math.Ceiling((dx + 1) / scale)));
                    int inkCount = 0;
                    for (int sy = y0; sy < y1; sy++)
                        for (int sx = x0; sx < x1; sx++)
                            if (raw[sy * width + sx]) inkCount++;
                    double coverage = (double)inkCount / ((y1 - y0) * (x1 - x0));
                    mask[(offsetY + dy) * ShapeSignature.Size + offsetX + dx] = coverage >= CoverageThreshold;
                }
            }
            return new ShapeSignature(mask, aspect);
        }

        private static int OtsuThreshold(byte[] gray)
        {
            var histogram = new long[256];
            foreach (byte value in gray) histogram[value]++;

            long total = gray.Length;
            long sum = 0;
            for (int i = 0; i < 256; i++) sum += i * histogram[i];

            long sumBackground = 0;
            long weightBackground = 0;
            double bestVariance = -1;
            int best = 127;
            for (int t = 0; t < 256; t++)
            {
                weightBackground += histogram[t];
                if (weightBackground == 0) continue;
                long weightForeground = total - weightBackground;
                if (weightForeground == 0) break;
                sumBackground += t * histogram[t];
                double meanBackground = (double)sumBackground / weightBackground;
                double meanForeground = (double)(sum - sumBackground) / weightForeground;
                double between = (double)weightBackground * weightForeground
                    * (meanBackground - meanForeground) * (meanBackground - meanForeground);
                if (between > bestVariance)
                {
                    bestVariance = between;
                    best = t;
                }
            }
            return best;
        }
    }
}
