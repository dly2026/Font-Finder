﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;

namespace FontFinder
{
    /// <summary>One font with its soft pre-filter measurement (log of font/target aspect ratio).</summary>
    internal sealed class CoarseItem
    {
        public FontRow Row { get; private set; }
        public double LogRatio { get; private set; }

        public CoarseItem(FontRow row, double logRatio)
        {
            Row = row;
            LogRatio = logRatio;
        }
    }

    internal static class FontMatcher
    {
        private const string RenderVersion = "v3";
        private const double FocusedShare = 0.6;

        public static SearchOutcome Search(SearchRequest request, IProgress<int> progress)
        {
            if (request == null) throw new ArgumentNullException("request");
            if (request.Fonts == null) throw new ArgumentException("No fonts supplied.", "request");
            string text = (request.Text ?? string.Empty).Trim();
            if (text.Length == 0) throw new ArgumentException("The sample text is empty.", "request");

            SignatureStore store = request.Store ?? SignatureStore.Default;
            int candidateLimit = Math.Max(1, Math.Min(SearchSettings.MaxCandidates, request.CandidateLimit));
            int resultLimit = Math.Max(1, Math.Min(SearchSettings.MaxResults, request.ResultLimit));
            bool glyphMode = IsSingleTextElement(text);

            Report(progress, 1);
            ShapeSignature target = SignatureBuilder.FromImageFile(request.ImagePath, request.HasCrop,
                request.CropX, request.CropY, request.CropWidth, request.CropHeight);

            var outcome = new SearchOutcome { TotalFonts = request.Fonts.Count, LogPath = AppLog.LogPath };
            var stats = new SearchStats();
            var failures = new List<string>();

            // Stage 1 (only when there are more families than the shortlist allows): a soft aspect-ratio
            // estimate decides which families are compared in detail. It never excludes by itself.
            List<FontRow> shortlist;
            if (request.Fonts.Count <= candidateLimit)
            {
                shortlist = new List<FontRow>(request.Fonts);
            }
            else
            {
                var coarse = new List<CoarseItem>();
                for (int i = 0; i < request.Fonts.Count; i++)
                {
                    FontRow row = request.Fonts[i];
                    try
                    {
                        coarse.Add(new CoarseItem(row, CoarseLogRatio(row.Family, text, glyphMode, target, store)));
                    }
                    catch (Exception ex)
                    {
                        failures.Add(row.Family + ": " + ex.Message);
                    }
                    Report(progress, 2 + (int)(28.0 * (i + 1) / request.Fonts.Count));
                }
                shortlist = SelectShortlist(coarse, candidateLimit);
            }
            outcome.Shortlisted = shortlist.Count;

            // Stage 2: every shortlisted family receives the same detailed score.
            var scored = new List<FontRow>();
            for (int i = 0; i < shortlist.Count; i++)
            {
                FontRow row = shortlist[i];
                try
                {
                    FontStyle style;
                    ShapeSignature signature = GetFontSignature(row.Family, text, glyphMode, store, stats, out style);
                    double score = ShapeScorer.Combined(target, signature);
                    scored.Add(new FontRow
                    {
                        Family = row.Family,
                        Category = row.Category,
                        Style = FontStylePicker.Label(style),
                        Score = score,
                        Similarity = Formatting.Percent(score)
                    });
                }
                catch (Exception ex)
                {
                    failures.Add(row.Family + ": " + ex.Message);
                }
                Report(progress, 30 + (int)(68.0 * (i + 1) / shortlist.Count));
            }

            outcome.Rows = scored
                .OrderByDescending(r => r.Score)
                .ThenBy(r => r.Family, StringComparer.OrdinalIgnoreCase)
                .Take(resultLimit)
                .ToList();
            outcome.Scored = scored.Count;
            outcome.Failed = failures.Count;
            outcome.MemoryHits = stats.MemoryHits;
            outcome.DiskHits = stats.DiskHits;
            outcome.Generated = stats.Generated;

            if (failures.Count > 0)
            {
                AppLog.Write("Search skipped " + failures.Count + " font(s):" + Environment.NewLine
                    + string.Join(Environment.NewLine, failures.Take(200)));
            }
            Report(progress, 100);
            return outcome;
        }

        /// <summary>
        /// Chooses at most 'limit' families. 60% are the closest by aspect ratio; the remaining slots are
        /// spread evenly (separately among wider and narrower families) across the rest, so unusual widths
        /// are represented instead of being dropped.
        /// </summary>
        internal static List<FontRow> SelectShortlist(IList<CoarseItem> items, int limit)
        {
            if (items.Count <= limit) return items.Select(i => i.Row).ToList();

            List<CoarseItem> ordered = items
                .OrderBy(i => Math.Abs(i.LogRatio))
                .ThenBy(i => i.Row.Family, StringComparer.OrdinalIgnoreCase)
                .ToList();

            int focused = (int)Math.Round(limit * FocusedShare);
            var chosen = ordered.Take(focused).ToList();
            List<CoarseItem> rest = ordered.Skip(focused).ToList();
            int slots = limit - chosen.Count;

            List<CoarseItem> wider = rest.Where(i => i.LogRatio >= 0).ToList();
            List<CoarseItem> narrower = rest.Where(i => i.LogRatio < 0).ToList();
            int takeNarrower = Math.Min(narrower.Count, slots / 2);
            int takeWider = Math.Min(wider.Count, slots - takeNarrower);
            takeNarrower = Math.Min(narrower.Count, slots - takeWider);

            chosen.AddRange(Spread(wider, takeWider));
            chosen.AddRange(Spread(narrower, takeNarrower));
            return chosen.Select(i => i.Row).ToList();
        }

        private static List<T> Spread<T>(List<T> list, int count)
        {
            var result = new List<T>();
            if (count <= 0 || list.Count == 0) return result;
            if (list.Count <= count)
            {
                result.AddRange(list);
                return result;
            }
            if (count == 1)
            {
                result.Add(list[list.Count / 2]);
                return result;
            }
            for (int i = 0; i < count; i++)
            {
                int index = (int)Math.Round(i * (list.Count - 1.0) / (count - 1.0));
                result.Add(list[index]);
            }
            return result;
        }

        internal static bool IsSingleTextElement(string text)
        {
            TextElementEnumerator elements = StringInfo.GetTextElementEnumerator(text);
            int count = 0;
            while (elements.MoveNext())
            {
                count++;
                if (count > 1) return false;
            }
            return count == 1;
        }

        internal static string SignatureKey(FontFamily family, FontStyle style, string text, bool glyphMode)
        {
            // The font fingerprint (metrics) invalidates cached samples if a font is replaced by another version.
            // A single character is cached per font and glyph, independent of the rest of the search text.
            return RenderVersion + "|" + family.Name + "|" + (int)style
                + "|" + family.GetEmHeight(style) + "|" + family.GetCellAscent(style)
                + "|" + family.GetCellDescent(style) + "|" + family.GetLineSpacing(style)
                + "|" + (glyphMode ? "glyph|" : "text|") + text;
        }

        private static ShapeSignature GetFontSignature(string familyName, string text, bool glyphMode,
            SignatureStore store, SearchStats stats, out FontStyle style)
        {
            using (var family = new FontFamily(familyName))
            {
                FontStyle used;
                if (!FontStylePicker.TryPick(family, out used))
                    throw new InvalidOperationException("no usable style (Regular/Bold/Italic/Bold Italic)");
                style = used;
                string key = SignatureKey(family, used, text, glyphMode);
                return store.GetOrCreate(key, () => RenderSignature(family, used, text, glyphMode), stats);
            }
        }

        private static ShapeSignature RenderSignature(FontFamily family, FontStyle style, string text, bool glyphMode)
        {
            int width = glyphMode ? 256 : 640;
            int height = glyphMode ? 256 : 200;
            float startSize = glyphMode ? 180f : 140f;
            using (Bitmap bitmap = GlyphRenderer.Render(family, style, text, width, height, startSize))
            {
                return SignatureBuilder.FromBitmap(bitmap, false);
            }
        }

        private static double CoarseLogRatio(string familyName, string text, bool glyphMode,
            ShapeSignature target, SignatureStore store)
        {
            using (var family = new FontFamily(familyName))
            {
                FontStyle style;
                if (!FontStylePicker.TryPick(family, out style))
                    throw new InvalidOperationException("no usable style (Regular/Bold/Italic/Bold Italic)");

                double aspect = 1.0;
                ShapeSignature cached = store.TryGetCached(SignatureKey(family, style, text, glyphMode));
                if (cached != null)
                {
                    aspect = cached.AspectRatio;
                }
                else
                {
                    int width = glyphMode ? 96 : 320;
                    int height = glyphMode ? 96 : 100;
                    float startSize = glyphMode ? 72f : 70f;
                    using (Bitmap bitmap = GlyphRenderer.Render(family, style, text, width, height, startSize))
                    {
                        aspect = SignatureBuilder.FromBitmap(bitmap, false).AspectRatio;
                    }
                }
                return Math.Log(Math.Max(0.01, aspect) / Math.Max(0.01, target.AspectRatio));
            }
        }

        private static void Report(IProgress<int> progress, int value)
        {
            if (progress != null) progress.Report(Math.Max(0, Math.Min(100, value)));
        }
    }
}
