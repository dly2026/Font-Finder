﻿using System;

namespace FontFinder
{
    /// <summary>
    /// Scale-normalised binary glyph mask (64x64) plus cheap derived features.
    /// The distance map is built lazily because it is not stored in the cache.
    /// </summary>
    internal sealed class ShapeSignature
    {
        public const int Size = 64;

        private float[] _distanceMap;

        public bool[] Mask { get; }
        public double AspectRatio { get; }
        public double InkRatio { get; }
        public double CenterX { get; }
        public double CenterY { get; }
        public double[] RowProjection { get; }
        public double[] ColumnProjection { get; }

        public float[] DistanceMap
        {
            get { return _distanceMap ?? (_distanceMap = BuildDistanceMap(Mask)); }
        }

        public ShapeSignature(bool[] mask, double aspectRatio)
        {
            if (mask == null || mask.Length != Size * Size)
                throw new ArgumentException("Mask must contain " + (Size * Size) + " cells.", "mask");

            Mask = mask;
            AspectRatio = aspectRatio;
            RowProjection = new double[Size];
            ColumnProjection = new double[Size];

            double sumX = 0, sumY = 0;
            int ink = 0;
            for (int y = 0; y < Size; y++)
            {
                for (int x = 0; x < Size; x++)
                {
                    if (!mask[y * Size + x]) continue;
                    ink++;
                    sumX += x;
                    sumY += y;
                    RowProjection[y]++;
                    ColumnProjection[x]++;
                }
            }

            InkRatio = (double)ink / mask.Length;
            CenterX = ink == 0 ? 0.5 : sumX / ink / (Size - 1);
            CenterY = ink == 0 ? 0.5 : sumY / ink / (Size - 1);
            for (int i = 0; i < Size; i++)
            {
                RowProjection[i] /= Size;
                ColumnProjection[i] /= Size;
            }
        }

        // Two-pass chamfer distance transform (distance to the nearest ink cell).
        private static float[] BuildDistanceMap(bool[] mask)
        {
            const float diagonal = 1.41421356f;
            var distance = new float[mask.Length];
            for (int i = 0; i < mask.Length; i++) distance[i] = mask[i] ? 0f : 1000f;

            for (int y = 0; y < Size; y++)
            {
                for (int x = 0; x < Size; x++)
                {
                    int i = y * Size + x;
                    float d = distance[i];
                    if (x > 0) d = Math.Min(d, distance[i - 1] + 1f);
                    if (y > 0) d = Math.Min(d, distance[i - Size] + 1f);
                    if (x > 0 && y > 0) d = Math.Min(d, distance[i - Size - 1] + diagonal);
                    if (x < Size - 1 && y > 0) d = Math.Min(d, distance[i - Size + 1] + diagonal);
                    distance[i] = d;
                }
            }

            for (int y = Size - 1; y >= 0; y--)
            {
                for (int x = Size - 1; x >= 0; x--)
                {
                    int i = y * Size + x;
                    float d = distance[i];
                    if (x < Size - 1) d = Math.Min(d, distance[i + 1] + 1f);
                    if (y < Size - 1) d = Math.Min(d, distance[i + Size] + 1f);
                    if (x < Size - 1 && y < Size - 1) d = Math.Min(d, distance[i + Size + 1] + diagonal);
                    if (x > 0 && y < Size - 1) d = Math.Min(d, distance[i + Size - 1] + diagonal);
                    distance[i] = d;
                }
            }
            return distance;
        }
    }
}
