﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Text;
using System.Security.Cryptography;
using System.Text;

namespace FontFinder
{
    /// <summary>Lists installed font families together with their descriptive category.</summary>
    internal static class FontCatalog
    {
        public static List<FontRow> ScanInstalled()
        {
            var rows = new List<FontRow>();
            using (var installed = new InstalledFontCollection())
            {
                foreach (FontFamily family in installed.Families)
                {
                    string name = family.Name;
                    rows.Add(new FontRow
                    {
                        Family = name,
                        Category = FontClassifier.Classify(name).Label(),
                        Style = "Installed",
                        Similarity = string.Empty,
                        Score = 0
                    });
                }
            }
            rows.Sort((a, b) => string.Compare(a.Family, b.Family, StringComparison.CurrentCultureIgnoreCase));
            return rows;
        }

        /// <summary>Short fingerprint of the font list; part of the search-results cache key.</summary>
        public static string ComputeKey(IList<FontRow> rows)
        {
            var joined = new StringBuilder();
            foreach (FontRow row in rows) joined.Append(row.Family).Append('|');
            using (var sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(Encoding.UTF8.GetBytes(joined.ToString()));
                var key = new StringBuilder();
                for (int i = 0; i < 8; i++) key.Append(hash[i].ToString("x2"));
                return rows.Count + ":" + key;
            }
        }
    }
}
