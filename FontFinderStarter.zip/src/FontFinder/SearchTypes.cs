﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace FontFinder
{
    internal sealed class SearchRequest
    {
        public string ImagePath;
        public bool HasCrop;
        public int CropX, CropY, CropWidth, CropHeight;
        public string Text;
        public IList<FontRow> Fonts;
        public int CandidateLimit = SearchSettings.CandidateLimit;
        public int ResultLimit = SearchSettings.ResultLimit;
        /// <summary>Optional store override (tests). Null = the default per-user store.</summary>
        public SignatureStore Store;
    }

    internal sealed class SearchStats
    {
        public int MemoryHits;
        public int DiskHits;
        public int Generated;
    }

    internal sealed class SearchOutcome
    {
        public List<FontRow> Rows = new List<FontRow>();
        public int TotalFonts;
        public int Shortlisted;
        public int Scored;
        public int Failed;
        public int MemoryHits;
        public int DiskHits;
        public int Generated;
        public string LogPath;

        public SearchOutcome Clone()
        {
            var copy = (SearchOutcome)MemberwiseClone();
            copy.Rows = new List<FontRow>();
            foreach (FontRow row in Rows) copy.Rows.Add(row.Clone());
            return copy;
        }
    }

    internal static class Formatting
    {
        /// <summary>Culture-independent percentage text, e.g. "87.4%".</summary>
        public static string Percent(double value)
        {
            return value.ToString("0.0", CultureInfo.InvariantCulture) + "%";
        }
    }
}
