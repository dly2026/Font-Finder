﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace FontFinder
{
    /// <summary>Renders a glyph or a short text on a single line (no wrapping) as black ink on white.</summary>
    internal static class GlyphRenderer
    {
        private const float Margin = 8f;
        private const float MinimumSize = 6f;

        public static Bitmap Render(FontFamily family, FontStyle style, string text,
            int canvasWidth, int canvasHeight, float startSize)
        {
            var bitmap = new Bitmap(canvasWidth, canvasHeight, PixelFormat.Format32bppArgb);
            try
            {
                using (var graphics = Graphics.FromImage(bitmap))
                using (var format = CreateFormat(text))
                {
                    graphics.Clear(Color.White);
                    graphics.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;

                    // Measure on one unbounded line, then shrink (never enlarge) so the text fits the canvas.
                    float size = startSize;
                    using (var probe = new Font(family, startSize, style, GraphicsUnit.Pixel))
                    {
                        SizeF measured = graphics.MeasureString(text, probe, new SizeF(100000f, 100000f), format);
                        if (measured.Width > 0f && measured.Height > 0f)
                        {
                            float fitX = (canvasWidth - 2f * Margin) / measured.Width;
                            float fitY = (canvasHeight - 2f * Margin) / measured.Height;
                            float factor = Math.Min(1f, Math.Min(fitX, fitY));
                            size = Math.Max(MinimumSize, startSize * factor);
                        }
                    }

                    using (var font = new Font(family, size, style, GraphicsUnit.Pixel))
                    using (var brush = new SolidBrush(Color.Black))
                    {
                        graphics.DrawString(text, font, brush, new RectangleF(0f, 0f, canvasWidth, canvasHeight), format);
                    }
                }
                return bitmap;
            }
            catch
            {
                bitmap.Dispose();
                throw;
            }
        }

        private static StringFormat CreateFormat(string text)
        {
            StringFormatFlags flags = StringFormatFlags.NoWrap | StringFormatFlags.NoClip;
            if (ContainsRightToLeft(text)) flags |= StringFormatFlags.DirectionRightToLeft;
            return new StringFormat
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center,
                FormatFlags = flags,
                Trimming = StringTrimming.None
            };
        }

        private static bool ContainsRightToLeft(string text)
        {
            foreach (char c in text)
            {
                if ((c >= 0x0590 && c <= 0x08FF) || (c >= 0xFB1D && c <= 0xFDFF) || (c >= 0xFE70 && c <= 0xFEFF))
                    return true;
            }
            return false;
        }
    }
}
