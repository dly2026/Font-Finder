﻿
namespace FontFinder
{
    /// <summary>
    /// Descriptive font classification.
    /// Informational only; never used as a search filter.
    /// </summary>
    internal enum FontCategory
    {
        Unknown,

        // Main type classifications
        Serif,
        SansSerif,
        SlabSerif,
        Script,
        Handwriting,
        Display,
        Blackletter,
        Monospaced,
        Decorative,
        PixelDigital,
        Symbol,

        // Serif subcategories
        OldStyleSerif,
        VenetianSerif,
        HumanistSerif,
        GaraldeSerif,
        TransitionalSerif,
        BaroqueSerif,
        NeoclassicalSerif,
        ModernSerif,
        Didone,
        ScotchRoman,
        ScotchModern,
        Egyptian,
        Clarendon,
        AntiqueSerif,
        TuscanSerif,
        WedgeSerif,
        GlyphicSerif,
        InscriptionalSerif,
        FatFace,
        HairlineSerif,
        GeometricSerif,

        // Sans Serif subcategories
        Grotesque,
        NeoGrotesque,
        GeometricSans,
        HumanistSans,
        HumanisticGrotesque,
        TransitionalSans,
        RealistSans,
        SwissSans,
        GothicSans,
        SquareSans,
        RoundedSans,
        IndustrialSans,
        NeoHumanistSans,
        ModularSans,
        MinimalSans,
        NeoGeometricSans,

        // Slab Serif subcategories
        EgyptianSlab,
        GeometricSlab,
        HumanistSlab,
        ClarendonSlab,
        SquareSlab,
        RoundedSlab,
        AntiqueSlab,
        NeoSlab,
        WesternSlab,

        // Script subcategories
        FormalScript,
        CasualScript,
        BrushScript,
        CalligraphicScript,
        CopperplateScript,
        RoundhandScript,
        SpencerianScript,
        EngraversScript,
        WeddingScript,
        SignatureScript,
        MonolineScript,
        ModernScript,
        ConnectedScript,
        FlourishedScript,
        ChanceryScript,
        CursiveScript,

        // Handwriting subcategories
        NaturalHandwriting,
        CasualHandwriting,
        FormalHandwriting,
        PrintHandwriting,
        CursiveHandwriting,
        ChildrensHandwriting,
        SchoolHandwriting,
        NeatHandwriting,
        MessyHandwriting,
        MarkerHandwriting,
        PencilHandwriting,
        ChalkHandwriting,
        HandDrawnLetters,

        // Display subcategories
        Headline,
        Poster,
        Impact,
        Experimental,
        Expressive,
        Artistic,
        Novelty,
        Ornamental,
        Stylized,
        Abstract,
        Conceptual,
        PsychedelicDisplay,
        RetroDisplay,
        VintageDisplay,
        FuturisticDisplay,
        ComicDisplay,
        IllustratedLettering,

        // Blackletter subcategories
        Textura,
        TexturaQuadrata,
        TexturaPrescisus,
        Rotunda,
        Schwabacher,
        Fraktur,
        Bastarda,
        Lombardic,
        ModernBlackletter,

        // Monospaced subcategories
        Typewriter,
        Coding,
        Programming,
        Terminal,
        Console,
        OCR,
        TechnicalMonospace,
        GeometricMonospace,
        HumanistMonospace,
        PixelMonospace,
        RetroMonospace,

        // Decorative and thematic styles
        ArtDeco,
        ArtNouveau,
        Victorian,
        Western,
        Circus,
        Carnival,
        Horror,
        Halloween,
        Christmas,
        Easter,
        Valentine,
        Tattoo,
        Graffiti,
        Stencil,
        Inline,
        Outline,
        Shadow,
        ThreeDimensional,
        Layered,
        Distressed,
        Grunge,
        Rough,
        Weathered,
        Worn,
        Eroded,
        Retro,
        Vintage,
        Futuristic,
        SciFi,
        Cyberpunk,
        Techno,
        Military,
        Sports,
        Athletic,
        College,
        Varsity,
        Comic,
        Cartoon,
        Kids,
        Bubble,
        Neon,
        Glitch,
        Stacked,
        Cutout,
        Floral,
        Botanical,
        Tribal,
        Pictorial,

        // Pixel and digital subcategories
        Pixel,
        Bitmap,
        EightBit,
        SixteenBit,
        Arcade,
        RetroGaming,
        DotMatrix,
        LED,
        LCD,
        DigitalClock,
        ScreenOptimized,
        LowResolution,
        RasterDisplay,

        // Symbol subcategories
        Dingbats,
        Symbols,
        Icons,
        Pictograms,
        Emoji,
        Arrows,
        MathematicalSymbols,
        CurrencySymbols,
        TechnicalSymbols,
        MusicalSymbols,
        ReligiousSymbols,
        DecorativeSymbols,
        Ornaments,
        Borders,
        Bullets,
        UIIcons,
        LogoSymbols,
        MapSymbols
    }

    internal static class FontCategoryExtensions
    {
        public static string Label(this FontCategory category)
        {
            switch (category)
            {
                case FontCategory.Serif: return "Serif";
                case FontCategory.SansSerif: return "Sans Serif";
                case FontCategory.SlabSerif: return "Slab Serif";
                case FontCategory.Script: return "Script";
                case FontCategory.Handwriting: return "Handwriting";
                case FontCategory.Display: return "Display";
                case FontCategory.Blackletter: return "Blackletter";
                case FontCategory.Monospaced: return "Monospaced";
                case FontCategory.Decorative: return "Decorative";
                case FontCategory.PixelDigital: return "Pixel / Digital";
                case FontCategory.Symbol: return "Symbol";
                default: return category.ToString();
            }
        }
    }
}
