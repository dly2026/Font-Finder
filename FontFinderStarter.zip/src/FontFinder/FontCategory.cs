﻿namespace FontFinder
{
    /// <summary>Descriptive font category. Informational only; never a search filter.</summary>
    internal enum FontCategory
    {
        Unknown,
        Serif,
        SansSerif,
        Script,
        Display,
        Monospaced,
        Bitmap,
        Symbol
    }

    internal static class FontCategoryExtensions
    {
        public static string Label(this FontCategory category)
        {
            switch (category)
            {
                case FontCategory.Serif: return "Serif";
                case FontCategory.SansSerif: return "Sans Serif";
                case FontCategory.Script: return "Script";
                case FontCategory.Display: return "Display";
                case FontCategory.Monospaced: return "Monospaced";
                case FontCategory.Bitmap: return "Bitmap";
                case FontCategory.Symbol: return "Symbol";
                default: return "Unknown";
            }
        }
    }
}
