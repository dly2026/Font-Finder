﻿using System;
using System.Collections.Concurrent;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace FontFinder
{
    /// <summary>
    /// Persistent font-signature cache (memory + disk). It is independent of the search-results cache.
    /// Files are written atomically (temp file + move), carry a checksum, and any unreadable file is
    /// deleted and rebuilt automatically.
    /// </summary>
    internal sealed class SignatureStore
    {
        private const int Magic = 0x31534646; // "FFS1"
        private const int FormatVersion = 3;
        private const int PackedLength = (ShapeSignature.Size * ShapeSignature.Size) / 8;
        private const int FileLength = 4 + 4 + 8 + 4 + PackedLength + 4;

        private readonly string _folder;
        private readonly ConcurrentDictionary<string, ShapeSignature> _memory =
            new ConcurrentDictionary<string, ShapeSignature>(StringComparer.Ordinal);

        public static readonly SignatureStore Default = new SignatureStore(DefaultFolder());

        public SignatureStore(string folder)
        {
            _folder = folder;
        }

        public string Folder
        {
            get { return _folder; }
        }

        public static string DefaultFolder()
        {
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "FontFinder", "Signatures");
        }

        public ShapeSignature GetOrCreate(string key, Func<ShapeSignature> factory, SearchStats stats)
        {
            ShapeSignature signature;
            if (_memory.TryGetValue(key, out signature))
            {
                stats.MemoryHits++;
                return signature;
            }

            signature = TryLoad(key);
            if (signature != null)
            {
                _memory[key] = signature;
                stats.DiskHits++;
                return signature;
            }

            signature = factory();
            _memory[key] = signature;
            stats.Generated++;
            Save(key, signature);
            return signature;
        }

        /// <summary>Returns a cached signature (memory or disk) without creating one.</summary>
        public ShapeSignature TryGetCached(string key)
        {
            ShapeSignature signature;
            if (_memory.TryGetValue(key, out signature)) return signature;
            signature = TryLoad(key);
            if (signature != null) _memory[key] = signature;
            return signature;
        }

        public string GetPath(string key)
        {
            using (var sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(Encoding.UTF8.GetBytes(key));
                var builder = new StringBuilder(hash.Length * 2);
                foreach (byte b in hash) builder.Append(b.ToString("x2"));
                return Path.Combine(_folder, builder + ".bin");
            }
        }

        /// <summary>Deletes every cached signature (memory and disk). Returns the number of files removed.</summary>
        public int Clear()
        {
            _memory.Clear();
            int removed = 0;
            try
            {
                if (!Directory.Exists(_folder)) return 0;
                foreach (string file in Directory.GetFiles(_folder))
                {
                    string extension = Path.GetExtension(file);
                    if (!string.Equals(extension, ".bin", StringComparison.OrdinalIgnoreCase)
                        && !string.Equals(extension, ".tmp", StringComparison.OrdinalIgnoreCase)) continue;
                    if (TryDelete(file)) removed++;
                }
            }
            catch (Exception ex)
            {
                AppLog.Write("Could not clear the signature cache: " + ex.Message);
            }
            return removed;
        }

        private ShapeSignature TryLoad(string key)
        {
            string path = GetPath(key);
            if (!File.Exists(path)) return null;
            try
            {
                ShapeSignature signature = Decode(File.ReadAllBytes(path));
                if (signature != null) return signature;
                AppLog.Write("Corrupt signature cache file removed and will be rebuilt: " + path);
            }
            catch (Exception ex)
            {
                AppLog.Write("Unreadable signature cache file removed and will be rebuilt (" + path + "): " + ex.Message);
            }
            TryDelete(path);
            return null;
        }

        private void Save(string key, ShapeSignature signature)
        {
            string path = GetPath(key);
            string temp = null;
            try
            {
                Directory.CreateDirectory(_folder);
                byte[] data = Encode(signature);
                temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
                File.WriteAllBytes(temp, data);
                if (File.Exists(path)) File.Delete(path);
                File.Move(temp, path);
                temp = null;
            }
            catch (Exception ex)
            {
                AppLog.Write("Could not save a signature cache file (" + path + "): " + ex.Message);
            }
            finally
            {
                if (temp != null) TryDelete(temp);
            }
        }

        private static bool TryDelete(string path)
        {
            try
            {
                File.Delete(path);
                return true;
            }
            catch (Exception ex)
            {
                AppLog.Write("Could not delete cache file " + path + ": " + ex.Message);
                return false;
            }
        }

        private static byte[] Encode(ShapeSignature signature)
        {
            byte[] packed = Pack(signature.Mask);
            using (var stream = new MemoryStream(FileLength))
            using (var writer = new BinaryWriter(stream))
            {
                writer.Write(Magic);
                writer.Write(FormatVersion);
                writer.Write(signature.AspectRatio);
                writer.Write(ShapeSignature.Size);
                writer.Write(packed);
                writer.Write(Checksum(signature.AspectRatio, packed));
                writer.Flush();
                return stream.ToArray();
            }
        }

        private static ShapeSignature Decode(byte[] bytes)
        {
            if (bytes == null || bytes.Length != FileLength) return null;
            using (var stream = new MemoryStream(bytes))
            using (var reader = new BinaryReader(stream))
            {
                if (reader.ReadInt32() != Magic) return null;
                if (reader.ReadInt32() != FormatVersion) return null;
                double aspect = reader.ReadDouble();
                if (reader.ReadInt32() != ShapeSignature.Size) return null;
                byte[] packed = reader.ReadBytes(PackedLength);
                uint stored = reader.ReadUInt32();
                if (packed.Length != PackedLength) return null;
                if (stored != Checksum(aspect, packed)) return null;
                if (double.IsNaN(aspect) || double.IsInfinity(aspect) || aspect <= 0.0) return null;
                return new ShapeSignature(Unpack(packed), aspect);
            }
        }

        private static byte[] Pack(bool[] mask)
        {
            var packed = new byte[PackedLength];
            for (int i = 0; i < mask.Length; i++)
            {
                if (mask[i]) packed[i >> 3] |= (byte)(1 << (i & 7));
            }
            return packed;
        }

        private static bool[] Unpack(byte[] packed)
        {
            var mask = new bool[ShapeSignature.Size * ShapeSignature.Size];
            for (int i = 0; i < mask.Length; i++)
            {
                mask[i] = (packed[i >> 3] & (1 << (i & 7))) != 0;
            }
            return mask;
        }

        // FNV-1a over the aspect ratio bytes and the packed mask.
        private static uint Checksum(double aspect, byte[] packed)
        {
            uint hash = 2166136261;
            foreach (byte b in BitConverter.GetBytes(aspect))
            {
                hash ^= b;
                hash *= 16777619;
            }
            foreach (byte b in packed)
            {
                hash ^= b;
                hash *= 16777619;
            }
            return hash;
        }
    }
}
