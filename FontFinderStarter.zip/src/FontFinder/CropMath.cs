﻿using System;

namespace FontFinder
{
    /// <summary>Pure crop geometry so that edge handling can be tested without a UI.</summary>
    internal static class CropMath
    {
        /// <summary>
        /// Intersects a rectangle drawn on the canvas with the displayed image and converts it to
        /// integer image-pixel coordinates. Returns false when nothing useful is left.
        /// </summary>
        public static bool TryCanvasToImage(
            double left, double top, double width, double height,
            double scale, double offsetX, double offsetY,
            int imageWidth, int imageHeight, double minScreenSize,
            out int x, out int y, out int w, out int h)
        {
            x = y = w = h = 0;
            if (scale <= 0 || imageWidth <= 0 || imageHeight <= 0) return false;

            double shownW = imageWidth * scale;
            double shownH = imageHeight * scale;
            double l = Math.Max(left, offsetX);
            double t = Math.Max(top, offsetY);
            double r = Math.Min(left + width, offsetX + shownW);
            double b = Math.Min(top + height, offsetY + shownH);
            if (r - l < minScreenSize || b - t < minScreenSize) return false;

            int ix = Clamp((int)Math.Round((l - offsetX) / scale), 0, imageWidth - 1);
            int iy = Clamp((int)Math.Round((t - offsetY) / scale), 0, imageHeight - 1);
            int ir = Clamp((int)Math.Round((r - offsetX) / scale), ix + 1, imageWidth);
            int ib = Clamp((int)Math.Round((b - offsetY) / scale), iy + 1, imageHeight);

            x = ix;
            y = iy;
            w = ir - ix;
            h = ib - iy;
            return w >= 3 && h >= 3;
        }

        /// <summary>Clamps an integer rectangle to the image bounds.</summary>
        public static bool TryClamp(int x, int y, int w, int h, int imageWidth, int imageHeight,
            out int ox, out int oy, out int ow, out int oh)
        {
            ox = oy = ow = oh = 0;
            if (imageWidth <= 0 || imageHeight <= 0 || w <= 0 || h <= 0) return false;

            int left = Math.Max(0, x);
            int top = Math.Max(0, y);
            int right = Math.Min(imageWidth, x + w);
            int bottom = Math.Min(imageHeight, y + h);
            if (right <= left || bottom <= top) return false;

            ox = left;
            oy = top;
            ow = right - left;
            oh = bottom - top;
            return true;
        }

        private static int Clamp(int value, int min, int max)
        {
            if (max < min) return min;
            return Math.Max(min, Math.Min(max, value));
        }
    }
}
