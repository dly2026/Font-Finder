
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace FontFinder
{
    public partial class MainWindow : Window
    {
        private const string TypographyPlaceholder = "Select a crop to analyze glyph geometry.";
        private const double MinimumCropScreenSize = 8.0;

        private string _imagePath;
        private string _imageStamp = string.Empty;
        private string _defaultSample = string.Empty;
        private List<FontRow> _fontRows = new List<FontRow>();
        private string _fontsKey = string.Empty;

        private bool _isCropping;
        private Point _cropStart;
        private bool _hasCrop;
        private int _cropX, _cropY, _cropWidth, _cropHeight;
        private bool _isSearching;

        // Image pan state
        private TranslateTransform _imagePanTransform;
        private bool _isPanning;
        private Point _lastPanPoint;

        // In-memory results cache.
        private readonly Dictionary<string, SearchOutcome> _searchResultsCache =
            new Dictionary<string, SearchOutcome>(StringComparer.Ordinal);

        public MainWindow()
        {
            InitializeComponent();

            _defaultSample = SampleTextBox.Text ?? string.Empty;

            InitializeImagePan();
        }

        // --------------------------------------------------------- image pan setup

        private void InitializeImagePan()
        {
            if (ImageZoomLayer == null || InputImageScale == null)
                return;

            _imagePanTransform = new TranslateTransform();

            var transforms = new TransformGroup();
            transforms.Children.Add(InputImageScale);
            transforms.Children.Add(_imagePanTransform);

            ImageZoomLayer.RenderTransform = transforms;
        }

        private bool IsImageZoomed()
        {
            return ImageZoomSlider != null &&
                   ImageZoomSlider.Value > 1.001;
        }

        // --------------------------------------------------------- clipboard paste

        private void MainWindow_PreviewKeyDown(
            object sender,
            KeyEventArgs e)
        {
            // Keep normal text-paste behavior inside the sample text box.
            if (SampleTextBox != null &&
                SampleTextBox.IsKeyboardFocusWithin)
                return;

            if (e.Key == Key.V &&
                (Keyboard.Modifiers & ModifierKeys.Control) == ModifierKeys.Control)
            {
                PasteClipboardImage();
                e.Handled = true;
            }
        }

        private void PasteImage_Click(
            object sender,
            RoutedEventArgs e)
        {
            PasteClipboardImage();
        }

        private void PasteClipboardImage()
        {
            try
            {
                IDataObject data = Clipboard.GetDataObject();

                if (data == null)
                {
                    ShowClipboardError();
                    return;
                }

                BitmapSource image = null;

                // Standard WPF clipboard image.
                if (Clipboard.ContainsImage())
                    image = Clipboard.GetImage();

                // Bitmap format.
                if (image == null &&
                    data.GetDataPresent(DataFormats.Bitmap))
                {
                    image = data.GetData(DataFormats.Bitmap) as BitmapSource;
                }

                // PNG formats used by graphics applications.
                if (image == null)
                {
                    string[] formats =
                    {
                        "PNG",
                        "image/png"
                    };

                    foreach (string format in formats)
                    {
                        if (!data.GetDataPresent(format))
                            continue;

                        object value = data.GetData(format);

                        if (value is BitmapSource)
                        {
                            image = (BitmapSource)value;
                            break;
                        }

                        byte[] bytes = value as byte[];

                        if (bytes != null)
                        {
                            image = LoadImageFromBytes(bytes);

                            if (image != null)
                                break;
                        }

                        Stream sourceStream = value as Stream;

                        if (sourceStream != null)
                        {
                            using (var memory = new MemoryStream())
                            {
                                sourceStream.CopyTo(memory);
                                image = LoadImageFromBytes(memory.ToArray());
                            }

                            if (image != null)
                                break;
                        }
                    }
                }

                // If the clipboard contains copied image files.
                if (image == null &&
                    data.GetDataPresent(DataFormats.FileDrop))
                {
                    string[] files =
                        data.GetData(DataFormats.FileDrop) as string[];

                    if (files != null &&
                        files.Length > 0 &&
                        File.Exists(files[0]))
                    {
                        PasteImageFile(files[0]);
                        return;
                    }
                }

                if (image == null ||
                    image.PixelWidth <= 0 ||
                    image.PixelHeight <= 0)
                {
                    ShowClipboardError();
                    return;
                }

                PasteBitmapSource(image);
            }
            catch (Exception ex)
            {
                AppLog.Write("Could not paste image from clipboard: " + ex);

                StatusText.Text =
                    "Could not paste image from clipboard: " + ex.Message;
            }
        }

        private BitmapSource LoadImageFromBytes(byte[] bytes)
        {
            if (bytes == null || bytes.Length == 0)
                return null;

            using (var stream = new MemoryStream(bytes))
            {
                var bitmap = new BitmapImage();

                bitmap.BeginInit();
                bitmap.CacheOption = BitmapCacheOption.OnLoad;
                bitmap.StreamSource = stream;
                bitmap.EndInit();

                if (bitmap.CanFreeze)
                    bitmap.Freeze();

                return bitmap;
            }
        }

        private void PasteBitmapSource(BitmapSource clipboardImage)
        {
            BitmapSource image = clipboardImage.Clone();

            if (image.CanFreeze)
                image.Freeze();

            // Save the image as PNG because the search engine uses a file path.
            string tempPath = Path.Combine(
                Path.GetTempPath(),
                "FontFinder_Pasted_" +
                Guid.NewGuid().ToString("N") +
                ".png");

            var encoder = new PngBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(image));

            using (var stream = new FileStream(
                tempPath,
                FileMode.CreateNew,
                FileAccess.Write,
                FileShare.None))
            {
                encoder.Save(stream);
            }

            SetPastedImage(
                image,
                tempPath,
                "Pasted image from Clipboard");
        }

        private void PasteImageFile(string filePath)
        {
            var bitmap = new BitmapImage();

            bitmap.BeginInit();
            bitmap.CacheOption = BitmapCacheOption.OnLoad;
            bitmap.UriSource = new Uri(filePath);
            bitmap.EndInit();

            if (bitmap.CanFreeze)
                bitmap.Freeze();

            SetPastedImage(bitmap, filePath, filePath);
        }

        private void SetPastedImage(
            BitmapSource image,
            string imagePath,
            string displayName)
        {
            var info = new FileInfo(imagePath);

            InputImage.Source = image;
            _imagePath = imagePath;

            _imageStamp =
                info.LastWriteTimeUtc.Ticks.ToString(CultureInfo.InvariantCulture)
                + ":"
                + info.Length.ToString(CultureInfo.InvariantCulture);

            ImagePathText.Text = displayName;

            ResetCrop();
            ResetImageZoom();

            StatusText.Text =
                "Image pasted successfully. Enter its visible text, then click Find similar fonts.";
        }

        private void ShowClipboardError()
        {
            StatusText.Text =
                "Clipboard does not contain a supported image. Copy an image first, then try Paste again.";
        }

        // ---------------------------------------------------------------- image

        private void ChooseImage_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Title = "Choose an image",
                Filter = "Image files|*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.tif;*.tiff|All files|*.*"
            };

            if (dialog.ShowDialog() != true) return;

            try
            {
                var image = new BitmapImage();
                image.BeginInit();
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.UriSource = new Uri(dialog.FileName);
                image.EndInit();

                var info = new FileInfo(dialog.FileName);

                InputImage.Source = image;
                _imagePath = dialog.FileName;
                _imageStamp = info.LastWriteTimeUtc.Ticks.ToString(CultureInfo.InvariantCulture)
                    + ":" + info.Length.ToString(CultureInfo.InvariantCulture);

                ImagePathText.Text = dialog.FileName;

                ResetCrop();
                ResetImageZoom();

                StatusText.Text = "Image loaded. Enter its visible text, then click Find similar fonts.";
            }
            catch (Exception ex)
            {
                AppLog.Write("Could not load image '" + dialog.FileName + "': " + ex);
                MessageBox.Show("Could not load image: " + ex.Message,
                    "Font Finder", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ClearImage_Click(object sender, RoutedEventArgs e)
        {
            InputImage.Source = null;
            _imagePath = null;
            _imageStamp = string.Empty;

            ResetCrop();
            ResetImageZoom();

            ImagePathText.Text = "No image selected";
            StatusText.Text = "Image cleared.";
        }

        // -------------------------------------------------------------- image zoom

        private void ResetImageZoom()
        {
            if (ImageZoomSlider != null)
                ImageZoomSlider.Value = 1.0;

            if (_imagePanTransform != null)
            {
                _imagePanTransform.X = 0;
                _imagePanTransform.Y = 0;
            }

            ApplyImageZoom();
        }

        private void ImageZoomSlider_ValueChanged(
            object sender,
            RoutedPropertyChangedEventArgs<double> e)
        {
            ApplyImageZoom();
        }

        private void ApplyImageZoom()
        {
            if (InputImageScale == null)
                return;

            double zoom = ImageZoomSlider == null
                ? 1.0
                : ImageZoomSlider.Value;

            InputImageScale.ScaleX = zoom;
            InputImageScale.ScaleY = zoom;

            if (zoom <= 1.001 && _imagePanTransform != null)
            {
                _imagePanTransform.X = 0;
                _imagePanTransform.Y = 0;
            }

            if (ImageZoomLabel != null)
            {
                ImageZoomLabel.Text =
                    ((int)Math.Round(zoom * 100)).ToString(
                        CultureInfo.InvariantCulture) + "%";
            }

            if (CropCanvas != null)
                CropCanvas.Cursor = zoom > 1.001
                    ? Cursors.Hand
                    : Cursors.Cross;
        }

        private void ImageCanvasHost_PreviewMouseWheel(
            object sender,
            MouseWheelEventArgs e)
        {
            if ((Keyboard.Modifiers & ModifierKeys.Control) != ModifierKeys.Control)
                return;

            if (InputImage.Source == null || ImageZoomSlider == null)
                return;

            double step = e.Delta > 0 ? 0.1 : -0.1;

            double newZoom = ImageZoomSlider.Value + step;

            newZoom = Math.Max(
                ImageZoomSlider.Minimum,
                Math.Min(ImageZoomSlider.Maximum, newZoom));

            ImageZoomSlider.Value = Math.Round(newZoom, 1);

            e.Handled = true;
        }

        // ---------------------------------------------------------------- fonts

        private void ScanFonts_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _fontRows = FontCatalog.ScanInstalled();
                _fontsKey = FontCatalog.ComputeKey(_fontRows);

                FontsGrid.ItemsSource = null;
                FontsGrid.ItemsSource = _fontRows;

                if (_fontRows.Count > 0)
                    FontsGrid.SelectedIndex = 0;

                UpdateLivePreview();

                int unknown = _fontRows.Count(
                    r => r.Category == FontCategory.Unknown.Label());

                StatusText.Text = _fontRows.Count + " installed font families found (" + unknown
                    + " with unknown category; categories are descriptive only).";
            }
            catch (Exception ex)
            {
                AppLog.Write("Font scan failed: " + ex);
                StatusText.Text = "Font scan failed: " + ex.Message;
            }
        }

        private async void FindSimilar_Click(object sender, RoutedEventArgs e)
        {
            if (_isSearching) return;

            if (InputImage.Source == null || string.IsNullOrWhiteSpace(_imagePath))
            {
                StatusText.Text = "First choose an image.";
                return;
            }

            string sample = (SampleTextBox.Text ?? string.Empty).Trim();

            if (sample.Length == 0 ||
                string.Equals(sample, _defaultSample.Trim(), StringComparison.Ordinal))
            {
                StatusText.Text = "Enter the exact text visible in the image (replace the example text).";
                return;
            }

            if (_fontRows.Count == 0)
                ScanFonts_Click(sender, e);

            if (_fontRows.Count == 0) return;

            List<FontRow> fontSnapshot = _fontRows.ToList();
            int candidateLimit = SearchSettings.CandidateLimit;
            int resultLimit = SearchSettings.ResultLimit;

            string cacheKey = BuildResultsCacheKey(
                sample, candidateLimit, resultLimit);

            SearchOutcome cached;

            if (_searchResultsCache.TryGetValue(cacheKey, out cached))
            {
                ShowOutcome(cached.Clone(), true);
                return;
            }

            var request = new SearchRequest
            {
                ImagePath = _imagePath,
                HasCrop = _hasCrop,
                CropX = _cropX,
                CropY = _cropY,
                CropWidth = _cropWidth,
                CropHeight = _cropHeight,
                Text = sample,
                Fonts = fontSnapshot,
                CandidateLimit = candidateLimit,
                ResultLimit = resultLimit
            };

            _isSearching = true;

            FindSimilarButton.IsEnabled = false;
            ScanFontsButton.IsEnabled = false;

            SearchProgress.Value = 0;
            SearchProgress.Visibility = Visibility.Visible;

            StatusText.Text = "Analyzing crop and comparing font shapes...";

            var progress = new Progress<int>(
                value => SearchProgress.Value = value);

            try
            {
                SearchOutcome outcome = await Task.Run(
                    () => FontMatcher.Search(request, progress));

                _searchResultsCache[cacheKey] = outcome.Clone();

                ShowOutcome(outcome, false);
            }
            catch (Exception ex)
            {
                AppLog.Write("Comparison failed: " + ex);
                StatusText.Text = "Comparison failed: " + ex.Message;
            }
            finally
            {
                _isSearching = false;

                FindSimilarButton.IsEnabled = true;
                ScanFontsButton.IsEnabled = true;

                SearchProgress.Visibility = Visibility.Collapsed;
            }
        }

        private string BuildResultsCacheKey(
            string sample,
            int candidateLimit,
            int resultLimit)
        {
            string crop = _hasCrop
                ? string.Join(",", new[] { _cropX, _cropY, _cropWidth, _cropHeight }
                    .Select(v => v.ToString(CultureInfo.InvariantCulture)))
                : "full";

            return string.Join("\u001f", new[]
            {
                _imagePath,
                _imageStamp,
                crop,
                sample,
                candidateLimit.ToString(CultureInfo.InvariantCulture),
                resultLimit.ToString(CultureInfo.InvariantCulture),
                _fontsKey,
                "score-70-20-10-v3"
            });
        }

        private void ShowOutcome(SearchOutcome outcome, bool fromCache)
        {
            FontsGrid.ItemsSource = outcome.Rows;

            if (outcome.Rows.Count > 0)
                FontsGrid.SelectedIndex = 0;

            UpdateLivePreview();

            string status = (fromCache ? "From search cache: " : string.Empty)
                + "compared " + outcome.Scored + " of " + outcome.TotalFonts
                + " installed font families";

            if (outcome.TotalFonts > outcome.Shortlisted && outcome.Shortlisted > 0)
                status += " (prefilter shortlist " + outcome.Shortlisted + ")";

            status += ". Showing " + outcome.Rows.Count + " match(es)";

            if (!fromCache)
            {
                status += ". Signatures: " + outcome.MemoryHits + " memory, "
                    + outcome.DiskHits + " disk, "
                    + outcome.Generated + " newly rendered";
            }

            if (outcome.Failed > 0)
                status += ". " + outcome.Failed + " font(s) skipped, see " + outcome.LogPath;

            StatusText.Text = status + ".";

            // Add category summary without changing search results or ranking.
            UpdateCategoryAnalysis(outcome);
        }

        private void UpdateCategoryAnalysis(SearchOutcome outcome)
        {
            const string marker =
                "\n\nCategories most represented in top matches:\n";

            string baseText = TypographyAnalysisText.Text ?? string.Empty;

            // Remove an older category report, if present.
            int markerIndex = baseText.IndexOf(
                marker,
                StringComparison.Ordinal);

            if (markerIndex >= 0)
                baseText = baseText.Substring(0, markerIndex);

            if (outcome == null || outcome.Rows == null ||
                outcome.Rows.Count == 0)
            {
                TypographyAnalysisText.Text = baseText;
                return;
            }

            string unknownCategory = FontCategory.Unknown.Label();

            var groups = outcome.Rows
                .Where(r => r != null &&
                            !string.IsNullOrWhiteSpace(r.Category) &&
                            !string.Equals(
                                r.Category.Trim(),
                                unknownCategory,
                                StringComparison.OrdinalIgnoreCase))
                .GroupBy(
                    r => r.Category.Trim(),
                    StringComparer.OrdinalIgnoreCase)
                .Select(g => new
                {
                    Category = g.Key,
                    Count = g.Count(),
                    Best = g.OrderByDescending(r => r.Score).First()
                })
                .OrderByDescending(g => g.Best.Score)
                .ThenByDescending(g => g.Count)
                .Take(5)
                .ToList();

            if (groups.Count == 0)
            {
                TypographyAnalysisText.Text =
                    baseText + marker + "No category information available.";
                return;
            }

            string report = string.Join(
                "\n",
                groups.Select(g =>
                    g.Category + " — " +
                    g.Count + " font(s), best match: " +
                    g.Best.Similarity));

            TypographyAnalysisText.Text = baseText + marker + report;
        }

        private void ClearSearchCache_Click(object sender, RoutedEventArgs e)
        {
            _searchResultsCache.Clear();
            StatusText.Text = "Search results cache cleared. Cached font signatures were kept.";
        }

        private void ClearFontCache_Click(object sender, RoutedEventArgs e)
        {
            int removed = SignatureStore.Default.Clear();

            StatusText.Text = "Font signature cache cleared (" + removed
                + " files). Search results cache was kept.";
        }

        // ----------------------------------------------------------------- crop

        private bool TryGetImageLayout(
            out BitmapSource bitmap,
            out double scale,
            out double offsetX,
            out double offsetY)
        {
            bitmap = InputImage.Source as BitmapSource;

            scale = 0;
            offsetX = 0;
            offsetY = 0;

            if (bitmap == null ||
                bitmap.PixelWidth <= 0 ||
                bitmap.PixelHeight <= 0)
                return false;

            if (CropCanvas.ActualWidth <= 0 ||
                CropCanvas.ActualHeight <= 0)
                return false;

            scale = Math.Min(
                CropCanvas.ActualWidth / bitmap.PixelWidth,
                CropCanvas.ActualHeight / bitmap.PixelHeight);

            offsetX = (CropCanvas.ActualWidth - bitmap.PixelWidth * scale) / 2.0;
            offsetY = (CropCanvas.ActualHeight - bitmap.PixelHeight * scale) / 2.0;

            return scale > 0;
        }

        private void CropCanvas_MouseLeftButtonDown(
            object sender,
            MouseButtonEventArgs e)
        {
            if (InputImage.Source == null) return;

            if (IsImageZoomed() &&
                (Keyboard.Modifiers & ModifierKeys.Shift) != ModifierKeys.Shift)
            {
                if (_imagePanTransform == null)
                    return;

                _isPanning = true;
                _lastPanPoint = e.GetPosition(ImageCanvasHost);

                CropCanvas.Cursor = Cursors.SizeAll;
                CropCanvas.CaptureMouse();

                e.Handled = true;
                return;
            }

            _isCropping = true;
            _cropStart = e.GetPosition(CropCanvas);

            CropRectangle.Visibility = Visibility.Visible;

            Canvas.SetLeft(CropRectangle, _cropStart.X);
            Canvas.SetTop(CropRectangle, _cropStart.Y);

            CropRectangle.Width = 0;
            CropRectangle.Height = 0;

            CropCanvas.Cursor = Cursors.Cross;
            CropCanvas.CaptureMouse();

            e.Handled = true;
        }

        private void CropCanvas_MouseMove(
            object sender,
            MouseEventArgs e)
        {
            if (_isPanning)
            {
                Point current = e.GetPosition(ImageCanvasHost);

                double deltaX = current.X - _lastPanPoint.X;
                double deltaY = current.Y - _lastPanPoint.Y;

                _imagePanTransform.X += deltaX;
                _imagePanTransform.Y += deltaY;

                _lastPanPoint = current;

                e.Handled = true;
                return;
            }

            if (!_isCropping) return;

            Point p = e.GetPosition(CropCanvas);

            Canvas.SetLeft(
                CropRectangle,
                Math.Min(_cropStart.X, p.X));

            Canvas.SetTop(
                CropRectangle,
                Math.Min(_cropStart.Y, p.Y));

            CropRectangle.Width = Math.Abs(p.X - _cropStart.X);
            CropRectangle.Height = Math.Abs(p.Y - _cropStart.Y);
        }

        private void CropCanvas_MouseLeftButtonUp(
            object sender,
            MouseButtonEventArgs e)
        {
            if (_isPanning)
            {
                _isPanning = false;
                CropCanvas.ReleaseMouseCapture();

                CropCanvas.Cursor = IsImageZoomed()
                    ? Cursors.Hand
                    : Cursors.Cross;

                e.Handled = true;
                return;
            }

            if (!_isCropping) return;

            _isCropping = false;
            CropCanvas.ReleaseMouseCapture();

            CropCanvas.Cursor = IsImageZoomed()
                ? Cursors.Hand
                : Cursors.Cross;

            double left = Canvas.GetLeft(CropRectangle);
            double top = Canvas.GetTop(CropRectangle);
            double width = CropRectangle.Width;
            double height = CropRectangle.Height;

            BitmapSource bitmap;
            double scale, offsetX, offsetY;

            if (!TryGetImageLayout(
                out bitmap, out scale, out offsetX, out offsetY))
            {
                ResetCrop();
                return;
            }

            int x, y, w, h;

            if (!CropMath.TryCanvasToImage(
                left,
                top,
                width,
                height,
                scale,
                offsetX,
                offsetY,
                bitmap.PixelWidth,
                bitmap.PixelHeight,
                MinimumCropScreenSize,
                out x,
                out y,
                out w,
                out h))
            {
                ResetCrop();

                StatusText.Text =
                    "Crop selection too small or outside the image. Drag a larger rectangle around the text.";

                return;
            }

            _cropX = x;
            _cropY = y;
            _cropWidth = w;
            _cropHeight = h;

            _hasCrop = true;

            PositionCropRectangle();
            UpdateCropPreview();
            UpdateTypographyAnalysis();

            StatusText.Text =
                "Crop selected. Typography features are estimated from this crop.";
        }

        private void ImageCanvasHost_SizeChanged(
            object sender,
            SizeChangedEventArgs e)
        {
            if (_hasCrop)
                PositionCropRectangle();
        }

        private void ClearCrop_Click(object sender, RoutedEventArgs e)
        {
            ResetCrop();

            StatusText.Text =
                "Crop cleared. The full image will be compared.";
        }

        private void ResetCrop()
        {
            _hasCrop = false;

            CropRectangle.Visibility = Visibility.Collapsed;
            CropPreviewImage.Source = null;

            TypographyAnalysisText.Text = TypographyPlaceholder;
        }

        private void PositionCropRectangle()
        {
            BitmapSource bitmap;
            double scale, offsetX, offsetY;

            if (!_hasCrop ||
                !TryGetImageLayout(
                    out bitmap, out scale, out offsetX, out offsetY))
            {
                CropRectangle.Visibility = Visibility.Collapsed;
                return;
            }

            Canvas.SetLeft(
                CropRectangle,
                offsetX + _cropX * scale);

            Canvas.SetTop(
                CropRectangle,
                offsetY + _cropY * scale);

            CropRectangle.Width = _cropWidth * scale;
            CropRectangle.Height = _cropHeight * scale;

            CropRectangle.Visibility = Visibility.Visible;
        }

        private void UpdateCropPreview()
        {
            var bitmap = InputImage.Source as BitmapSource;

            if (bitmap == null || !_hasCrop)
            {
                CropPreviewImage.Source = null;
                CropPreviewImage.Width = double.NaN;
                CropPreviewImage.Height = double.NaN;
                return;
            }

            try
            {
                var crop = new CroppedBitmap(
                    bitmap,
                    new Int32Rect(
                        _cropX,
                        _cropY,
                        _cropWidth,
                        _cropHeight));

                double scale = Math.Min(
                    1.0,
                    (double)SignatureBuilder.ProcessingMaxSide
                    / Math.Max(_cropWidth, _cropHeight));

                CropPreviewImage.Source =
                    new TransformedBitmap(
                        crop,
                        new ScaleTransform(scale, scale));

                ApplyCropPreviewLayout();
            }
            catch (Exception ex)
            {
                AppLog.Write(
                    "Could not build the crop preview: " + ex.Message);

                CropPreviewImage.Source = null;
                CropPreviewImage.Width = double.NaN;
                CropPreviewImage.Height = double.NaN;
            }
        }

        private void CropPreviewHost_SizeChanged(
            object sender,
            SizeChangedEventArgs e)
        {
            ApplyCropPreviewLayout();
        }

        private void SampleTextBox_TextChanged(
            object sender,
            TextChangedEventArgs e)
        {
            ApplyCropPreviewLayout();
        }

        private void ApplyCropPreviewLayout()
        {
            if (CropPreviewHost == null ||
                CropPreviewImage == null)
                return;

            var source = CropPreviewImage.Source as BitmapSource;

            if (source == null ||
                source.Width <= 0 ||
                source.Height <= 0)
            {
                CropPreviewImage.Width = double.NaN;
                CropPreviewImage.Height = double.NaN;

                CropPreviewImage.HorizontalAlignment =
                    HorizontalAlignment.Center;

                CropPreviewImage.VerticalAlignment =
                    VerticalAlignment.Center;

                return;
            }

            double availableWidth = Math.Max(
                1.0,
                CropPreviewHost.ActualWidth
                - CropPreviewHost.Padding.Left
                - CropPreviewHost.Padding.Right);

            double availableHeight = Math.Max(
                1.0,
                CropPreviewHost.ActualHeight
                - CropPreviewHost.Padding.Top
                - CropPreviewHost.Padding.Bottom);

            double fit = Math.Min(
                availableWidth / source.Width,
                availableHeight / source.Height);

            CropPreviewImage.Width = source.Width * fit;
            CropPreviewImage.Height = source.Height * fit;

            CropPreviewImage.VerticalAlignment =
                VerticalAlignment.Center;

            string sample = SampleTextBox == null
                ? string.Empty
                : (SampleTextBox.Text ?? string.Empty).Trim();

            int textElementCount = string.IsNullOrEmpty(sample)
                ? 0
                : new StringInfo(sample).LengthInTextElements;

            if (textElementCount <= 1)
            {
                CropPreviewImage.HorizontalAlignment =
                    HorizontalAlignment.Center;
            }
            else
            {
                bool? rightToLeft = GetFirstStrongDirection(sample);

                CropPreviewImage.HorizontalAlignment =
                    rightToLeft == true
                        ? HorizontalAlignment.Right
                        : HorizontalAlignment.Left;
            }
        }

        private static bool? GetFirstStrongDirection(string text)
        {
            foreach (char ch in text)
            {
                if (char.IsWhiteSpace(ch))
                    continue;

                int code = ch;

                if ((code >= 0x0590 && code <= 0x08FF) ||
                    (code >= 0xFB1D && code <= 0xFDFF) ||
                    (code >= 0xFE70 && code <= 0xFEFF) ||
                    (code >= 0x10800 && code <= 0x10FFF))
                    return true;

                if ((code >= 'A' && code <= 'Z') ||
                    (code >= 'a' && code <= 'z') ||
                    char.IsDigit(ch))
                    return false;
            }

            return null;
        }

        private void UpdateTypographyAnalysis()
        {
            if (string.IsNullOrWhiteSpace(_imagePath))
                return;

            try
            {
                ShapeSignature signature =
                    SignatureBuilder.FromImageFile(
                        _imagePath,
                        _hasCrop,
                        _cropX,
                        _cropY,
                        _cropWidth,
                        _cropHeight);

                string shapeClass;
                string confidence;

                if (signature.AspectRatio < 0.58)
                {
                    shapeClass = "Narrow / condensed glyph";
                    confidence = "moderate";
                }
                else if (signature.AspectRatio > 1.18)
                {
                    shapeClass = "Wide glyph";
                    confidence = "moderate";
                }
                else
                {
                    shapeClass = "Proportional glyph";
                    confidence = "low–moderate";
                }

                string density = signature.InkRatio < 0.16
                    ? "Light / open"
                    : (signature.InkRatio > 0.34
                        ? "Dense / heavy"
                        : "Medium coverage");

                CultureInfo inv = CultureInfo.InvariantCulture;

                TypographyAnalysisText.Text =
                    "Preliminary visual analysis (not a definitive font-family classification)\n" +
                    "Shape: " + shapeClass + " — " + confidence + " confidence\n" +
                    "Aspect ratio: " + signature.AspectRatio.ToString("0.00", inv) + "\n" +
                    "Ink coverage: " +
                    (signature.InkRatio * 100.0).ToString("0.0", inv) +
                    "% (" + density + ")\n" +
                    "Visual center: X " +
                    signature.CenterX.ToString("0.00", inv) +
                    " / Y " +
                    signature.CenterY.ToString("0.00", inv) + "\n" +
                    "Features are used as soft matching signals; other styles remain eligible.";
            }
            catch (Exception ex)
            {
                AppLog.Write(
                    "Typography analysis failed: " + ex.Message);

                TypographyAnalysisText.Text =
                    "Could not analyze this crop: " + ex.Message;
            }
        }

        // -------------------------------------------------------------- preview

        private void FontsGrid_SelectionChanged(
            object sender,
            SelectionChangedEventArgs e)
        {
            UpdateLivePreview();
        }

        private void PreviewZoom_ValueChanged(
            object sender,
            RoutedPropertyChangedEventArgs<double> e)
        {
            if (PreviewTextBlock == null)
                return;

            PreviewTextBlock.FontSize = e.NewValue;

            if (PreviewZoomLabel != null)
            {
                PreviewZoomLabel.Text =
                    ((int)e.NewValue).ToString(
                        CultureInfo.InvariantCulture) + " px";
            }
        }

        private void UpdateLivePreview()
        {
            if (PreviewTextBlock == null ||
                FontsGrid == null)
                return;

            var selected = FontsGrid.SelectedItem as FontRow;

            string text = SampleTextBox == null
                ? string.Empty
                : (SampleTextBox.Text ?? string.Empty);

            if (selected == null)
            {
                PreviewFontName.Text = "No font selected";

                PreviewTextBlock.Text =
                    string.IsNullOrWhiteSpace(text)
                        ? "Select a result to preview it here."
                        : text;

                PreviewTextBlock.FontFamily =
                    new FontFamily("Segoe UI");

                return;
            }

            PreviewFontName.Text =
                selected.Family + " — " + selected.Similarity;

            PreviewTextBlock.Text = text;
            PreviewTextBlock.FontFamily =
                new FontFamily(selected.Family);

            PreviewTextBlock.FontSize =
                PreviewZoom == null ? 42 : PreviewZoom.Value;
        }

        private void RenderPreview_Click(
            object sender,
            RoutedEventArgs e)
        {
            UpdateLivePreview();

            StatusText.Text =
                "Live preview updated. Use the Up/Down arrow keys to browse fonts.";
        }
    }
}
