﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace FontFinder
{
    public partial class MainWindow : Window
    {
        private const string TypographyPlaceholder = "Select a crop to analyze glyph geometry.";
        private const double MinimumCropScreenSize = 8.0;

        private string _imagePath;
        private string _imageStamp = string.Empty;
        private string _defaultSample = string.Empty;
        private List<FontRow> _fontRows = new List<FontRow>();
        private string _fontsKey = string.Empty;

        private bool _isCropping;
        private Point _cropStart;
        private bool _hasCrop;
        private int _cropX, _cropY, _cropWidth, _cropHeight;
        private bool _isSearching;

        // In-memory results cache. It is independent of the persistent font-signature cache.
        private readonly Dictionary<string, SearchOutcome> _searchResultsCache =
            new Dictionary<string, SearchOutcome>(StringComparer.Ordinal);

        public MainWindow()
        {
            InitializeComponent();
            _defaultSample = SampleTextBox.Text ?? string.Empty;
        }

        // ---------------------------------------------------------------- image

        private void ChooseImage_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Title = "Choose an image",
                Filter = "Image files|*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.tif;*.tiff|All files|*.*"
            };
            if (dialog.ShowDialog() != true) return;

            try
            {
                var image = new BitmapImage();
                image.BeginInit();
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.UriSource = new Uri(dialog.FileName);
                image.EndInit();

                var info = new FileInfo(dialog.FileName);
                InputImage.Source = image;
                _imagePath = dialog.FileName;
                _imageStamp = info.LastWriteTimeUtc.Ticks.ToString(CultureInfo.InvariantCulture)
                    + ":" + info.Length.ToString(CultureInfo.InvariantCulture);
                ImagePathText.Text = dialog.FileName;
                ResetCrop();
                StatusText.Text = "Image loaded. Enter its visible text, then click Find similar fonts.";
            }
            catch (Exception ex)
            {
                AppLog.Write("Could not load image '" + dialog.FileName + "': " + ex);
                MessageBox.Show("Could not load image: " + ex.Message, "Font Finder", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ClearImage_Click(object sender, RoutedEventArgs e)
        {
            InputImage.Source = null;
            _imagePath = null;
            _imageStamp = string.Empty;
            ResetCrop();
            ImagePathText.Text = "No image selected";
            StatusText.Text = "Image cleared.";
        }

        // ---------------------------------------------------------------- fonts

        private void ScanFonts_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _fontRows = FontCatalog.ScanInstalled();
                _fontsKey = FontCatalog.ComputeKey(_fontRows);
                FontsGrid.ItemsSource = null;
                FontsGrid.ItemsSource = _fontRows;
                if (_fontRows.Count > 0) FontsGrid.SelectedIndex = 0;
                UpdateLivePreview();
                int unknown = _fontRows.Count(r => r.Category == FontCategory.Unknown.Label());
                StatusText.Text = _fontRows.Count + " installed font families found (" + unknown
                    + " with unknown category; categories are descriptive only).";
            }
            catch (Exception ex)
            {
                AppLog.Write("Font scan failed: " + ex);
                StatusText.Text = "Font scan failed: " + ex.Message;
            }
        }

        private async void FindSimilar_Click(object sender, RoutedEventArgs e)
        {
            if (_isSearching) return;
            if (InputImage.Source == null || string.IsNullOrWhiteSpace(_imagePath))
            {
                StatusText.Text = "First choose an image.";
                return;
            }

            string sample = (SampleTextBox.Text ?? string.Empty).Trim();
            if (sample.Length == 0 || string.Equals(sample, _defaultSample.Trim(), StringComparison.Ordinal))
            {
                StatusText.Text = "Enter the exact text visible in the image (replace the example text).";
                return;
            }

            if (_fontRows.Count == 0) ScanFonts_Click(sender, e);
            if (_fontRows.Count == 0) return;

            List<FontRow> fontSnapshot = _fontRows.ToList();
            int candidateLimit = SearchSettings.CandidateLimit;
            int resultLimit = SearchSettings.ResultLimit;
            string cacheKey = BuildResultsCacheKey(sample, candidateLimit, resultLimit);

            SearchOutcome cached;
            if (_searchResultsCache.TryGetValue(cacheKey, out cached))
            {
                ShowOutcome(cached.Clone(), true);
                return;
            }

            var request = new SearchRequest
            {
                ImagePath = _imagePath,
                HasCrop = _hasCrop,
                CropX = _cropX,
                CropY = _cropY,
                CropWidth = _cropWidth,
                CropHeight = _cropHeight,
                Text = sample,
                Fonts = fontSnapshot,
                CandidateLimit = candidateLimit,
                ResultLimit = resultLimit
            };

            _isSearching = true;
            FindSimilarButton.IsEnabled = false;
            ScanFontsButton.IsEnabled = false;
            SearchProgress.Value = 0;
            SearchProgress.Visibility = Visibility.Visible;
            StatusText.Text = "Analyzing crop and comparing font shapes...";
            var progress = new Progress<int>(value => SearchProgress.Value = value);

            try
            {
                SearchOutcome outcome = await Task.Run(() => FontMatcher.Search(request, progress));
                _searchResultsCache[cacheKey] = outcome.Clone();
                ShowOutcome(outcome, false);
            }
            catch (Exception ex)
            {
                AppLog.Write("Comparison failed: " + ex);
                StatusText.Text = "Comparison failed: " + ex.Message;
            }
            finally
            {
                _isSearching = false;
                FindSimilarButton.IsEnabled = true;
                ScanFontsButton.IsEnabled = true;
                SearchProgress.Visibility = Visibility.Collapsed;
            }
        }

        private string BuildResultsCacheKey(string sample, int candidateLimit, int resultLimit)
        {
            string crop = _hasCrop
                ? string.Join(",", new[] { _cropX, _cropY, _cropWidth, _cropHeight }
                    .Select(v => v.ToString(CultureInfo.InvariantCulture)))
                : "full";
            return string.Join("\u001f", new[]
            {
                _imagePath, _imageStamp, crop, sample,
                candidateLimit.ToString(CultureInfo.InvariantCulture),
                resultLimit.ToString(CultureInfo.InvariantCulture),
                _fontsKey,
                "score-70-20-10-v3"
            });
        }

        private void ShowOutcome(SearchOutcome outcome, bool fromCache)
        {
            FontsGrid.ItemsSource = outcome.Rows;
            if (outcome.Rows.Count > 0) FontsGrid.SelectedIndex = 0;
            UpdateLivePreview();

            string status = (fromCache ? "From search cache: " : string.Empty)
                + "compared " + outcome.Scored + " of " + outcome.TotalFonts + " installed font families";
            if (outcome.TotalFonts > outcome.Shortlisted && outcome.Shortlisted > 0)
                status += " (prefilter shortlist " + outcome.Shortlisted + ")";
            status += ". Showing " + outcome.Rows.Count + " match(es)";
            if (!fromCache)
                status += ". Signatures: " + outcome.MemoryHits + " memory, " + outcome.DiskHits + " disk, "
                    + outcome.Generated + " newly rendered";
            if (outcome.Failed > 0)
                status += ". " + outcome.Failed + " font(s) skipped, see " + outcome.LogPath;
            StatusText.Text = status + ".";
        }

        private void ClearSearchCache_Click(object sender, RoutedEventArgs e)
        {
            _searchResultsCache.Clear();
            StatusText.Text = "Search results cache cleared. Cached font signatures were kept.";
        }

        private void ClearFontCache_Click(object sender, RoutedEventArgs e)
        {
            int removed = SignatureStore.Default.Clear();
            StatusText.Text = "Font signature cache cleared (" + removed + " files). Search results cache was kept.";
        }

        // ----------------------------------------------------------------- crop

        private bool TryGetImageLayout(out BitmapSource bitmap, out double scale, out double offsetX, out double offsetY)
        {
            bitmap = InputImage.Source as BitmapSource;
            scale = 0;
            offsetX = 0;
            offsetY = 0;
            if (bitmap == null || bitmap.PixelWidth <= 0 || bitmap.PixelHeight <= 0) return false;
            if (CropCanvas.ActualWidth <= 0 || CropCanvas.ActualHeight <= 0) return false;

            scale = Math.Min(CropCanvas.ActualWidth / bitmap.PixelWidth, CropCanvas.ActualHeight / bitmap.PixelHeight);
            offsetX = (CropCanvas.ActualWidth - bitmap.PixelWidth * scale) / 2.0;
            offsetY = (CropCanvas.ActualHeight - bitmap.PixelHeight * scale) / 2.0;
            return scale > 0;
        }

        private void CropCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (InputImage.Source == null) return;
            _isCropping = true;
            _cropStart = e.GetPosition(CropCanvas);
            CropRectangle.Visibility = Visibility.Visible;
            Canvas.SetLeft(CropRectangle, _cropStart.X);
            Canvas.SetTop(CropRectangle, _cropStart.Y);
            CropRectangle.Width = 0;
            CropRectangle.Height = 0;
            CropCanvas.CaptureMouse();
        }

        private void CropCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (!_isCropping) return;
            Point p = e.GetPosition(CropCanvas);
            Canvas.SetLeft(CropRectangle, Math.Min(_cropStart.X, p.X));
            Canvas.SetTop(CropRectangle, Math.Min(_cropStart.Y, p.Y));
            CropRectangle.Width = Math.Abs(p.X - _cropStart.X);
            CropRectangle.Height = Math.Abs(p.Y - _cropStart.Y);
        }

        private void CropCanvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (!_isCropping) return;
            _isCropping = false;
            CropCanvas.ReleaseMouseCapture();

            double left = Canvas.GetLeft(CropRectangle);
            double top = Canvas.GetTop(CropRectangle);
            double width = CropRectangle.Width;
            double height = CropRectangle.Height;

            BitmapSource bitmap;
            double scale, offsetX, offsetY;
            if (!TryGetImageLayout(out bitmap, out scale, out offsetX, out offsetY))
            {
                ResetCrop();
                return;
            }

            int x, y, w, h;
            if (!CropMath.TryCanvasToImage(left, top, width, height, scale, offsetX, offsetY,
                    bitmap.PixelWidth, bitmap.PixelHeight, MinimumCropScreenSize, out x, out y, out w, out h))
            {
                ResetCrop();
                StatusText.Text = "Crop selection too small or outside the image. Drag a larger rectangle around the text.";
                return;
            }

            _cropX = x;
            _cropY = y;
            _cropWidth = w;
            _cropHeight = h;
            _hasCrop = true;
            PositionCropRectangle();
            UpdateCropPreview();
            UpdateTypographyAnalysis();
            StatusText.Text = "Crop selected. Typography features are estimated from this crop.";
        }

        private void ImageCanvasHost_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (_hasCrop) PositionCropRectangle();
        }

        private void ClearCrop_Click(object sender, RoutedEventArgs e)
        {
            ResetCrop();
            StatusText.Text = "Crop cleared. The full image will be compared.";
        }

        private void ResetCrop()
        {
            _hasCrop = false;
            CropRectangle.Visibility = Visibility.Collapsed;
            CropPreviewImage.Source = null;
            TypographyAnalysisText.Text = TypographyPlaceholder;
        }

        // Draws the stored (image-pixel) crop on the canvas, clipped to the displayed image.
        private void PositionCropRectangle()
        {
            BitmapSource bitmap;
            double scale, offsetX, offsetY;
            if (!_hasCrop || !TryGetImageLayout(out bitmap, out scale, out offsetX, out offsetY))
            {
                CropRectangle.Visibility = Visibility.Collapsed;
                return;
            }
            Canvas.SetLeft(CropRectangle, offsetX + _cropX * scale);
            Canvas.SetTop(CropRectangle, offsetY + _cropY * scale);
            CropRectangle.Width = _cropWidth * scale;
            CropRectangle.Height = _cropHeight * scale;
            CropRectangle.Visibility = Visibility.Visible;
        }

        private void UpdateCropPreview()
        {
            var bitmap = InputImage.Source as BitmapSource;
            if (bitmap == null || !_hasCrop)
            {
                CropPreviewImage.Source = null;
                return;
            }
            try
            {
                var crop = new CroppedBitmap(bitmap, new Int32Rect(_cropX, _cropY, _cropWidth, _cropHeight));
                double scale = Math.Min(1.0, (double)SignatureBuilder.ProcessingMaxSide / Math.Max(_cropWidth, _cropHeight));
                CropPreviewImage.Source = new TransformedBitmap(crop, new ScaleTransform(scale, scale));
            }
            catch (Exception ex)
            {
                AppLog.Write("Could not build the crop preview: " + ex.Message);
                CropPreviewImage.Source = null;
            }
        }

        private void UpdateTypographyAnalysis()
        {
            if (string.IsNullOrWhiteSpace(_imagePath)) return;
            try
            {
                ShapeSignature signature = SignatureBuilder.FromImageFile(_imagePath, _hasCrop, _cropX, _cropY, _cropWidth, _cropHeight);
                string shapeClass;
                string confidence;
                if (signature.AspectRatio < 0.58) { shapeClass = "Narrow / condensed glyph"; confidence = "moderate"; }
                else if (signature.AspectRatio > 1.18) { shapeClass = "Wide glyph"; confidence = "moderate"; }
                else { shapeClass = "Proportional glyph"; confidence = "low–moderate"; }
                string density = signature.InkRatio < 0.16 ? "Light / open"
                    : (signature.InkRatio > 0.34 ? "Dense / heavy" : "Medium coverage");
                CultureInfo inv = CultureInfo.InvariantCulture;
                TypographyAnalysisText.Text =
                    "Preliminary visual analysis (not a definitive font-family classification)\n" +
                    "Shape: " + shapeClass + " — " + confidence + " confidence\n" +
                    "Aspect ratio: " + signature.AspectRatio.ToString("0.00", inv) + "\n" +
                    "Ink coverage: " + (signature.InkRatio * 100.0).ToString("0.0", inv) + "% (" + density + ")\n" +
                    "Visual center: X " + signature.CenterX.ToString("0.00", inv) + " / Y " + signature.CenterY.ToString("0.00", inv) + "\n" +
                    "Features are used as soft matching signals; other styles remain eligible.";
            }
            catch (Exception ex)
            {
                AppLog.Write("Typography analysis failed: " + ex.Message);
                TypographyAnalysisText.Text = "Could not analyze this crop: " + ex.Message;
            }
        }

        // -------------------------------------------------------------- preview

        private void FontsGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateLivePreview();
        }

        private void PreviewZoom_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (PreviewTextBlock == null) return;
            PreviewTextBlock.FontSize = e.NewValue;
            if (PreviewZoomLabel != null) PreviewZoomLabel.Text = ((int)e.NewValue).ToString(CultureInfo.InvariantCulture) + " px";
        }

        private void UpdateLivePreview()
        {
            if (PreviewTextBlock == null || FontsGrid == null) return;
            var selected = FontsGrid.SelectedItem as FontRow;
            string text = SampleTextBox == null ? string.Empty : (SampleTextBox.Text ?? string.Empty);
            if (selected == null)
            {
                PreviewFontName.Text = "No font selected";
                PreviewTextBlock.Text = string.IsNullOrWhiteSpace(text) ? "Select a result to preview it here." : text;
                PreviewTextBlock.FontFamily = new FontFamily("Segoe UI");
                return;
            }
            PreviewFontName.Text = selected.Family + " — " + selected.Similarity;
            PreviewTextBlock.Text = text;
            PreviewTextBlock.FontFamily = new FontFamily(selected.Family);
            PreviewTextBlock.FontSize = PreviewZoom == null ? 42 : PreviewZoom.Value;
        }

        private void RenderPreview_Click(object sender, RoutedEventArgs e)
        {
            UpdateLivePreview();
            StatusText.Text = "Live preview updated. Use the Up/Down arrow keys to browse fonts.";
        }
    }
}
