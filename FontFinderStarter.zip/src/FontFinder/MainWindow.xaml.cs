// --------------------------------------------------------- clipboard paste

private void MainWindow_PreviewKeyDown(
    object sender,
    KeyEventArgs e)
{
    // Keep normal text paste inside the sample text box.
    if (SampleTextBox != null && SampleTextBox.IsKeyboardFocusWithin)
        return;

    if (e.Key == Key.V &&
        (Keyboard.Modifiers & ModifierKeys.Control) == ModifierKeys.Control)
    {
        PasteClipboardImage();
        e.Handled = true;
    }
}

private void PasteImage_Click(
    object sender,
    RoutedEventArgs e)
{
    PasteClipboardImage();
}

private void PasteClipboardImage()
{
    try
    {
        IDataObject data = Clipboard.GetDataObject();

        if (data == null)
        {
            StatusText.Text = "Clipboard is empty.";
            return;
        }

        // 1. Try a directly copied bitmap.
        BitmapSource bitmap = null;

        try
        {
            bitmap = Clipboard.GetImage();
        }
        catch
        {
            // Try other clipboard formats below.
        }

        if (bitmap == null)
        {
            try
            {
                if (data.GetDataPresent(DataFormats.Bitmap, true))
                    bitmap = data.GetData(DataFormats.Bitmap, true) as BitmapSource;
            }
            catch
            {
                // Continue to other formats.
            }
        }

        // 2. Try PNG clipboard data.
        if (bitmap == null)
        {
            bitmap = TryGetClipboardPng(data);
        }

        if (bitmap != null &&
            bitmap.PixelWidth > 0 &&
            bitmap.PixelHeight > 0)
        {
            PasteBitmapSource(bitmap);
            return;
        }

        // 3. Try copied image files from File Explorer.
        if (data.GetDataPresent(DataFormats.FileDrop))
        {
            string[] files = data.GetData(DataFormats.FileDrop) as string[];

            if (files != null)
            {
                foreach (string file in files)
                {
                    if (string.IsNullOrWhiteSpace(file) ||
                        !File.Exists(file))
                        continue;

                    try
                    {
                        PasteImageFile(file);
                        return;
                    }
                    catch
                    {
                        // This file was not a readable image.
                    }
                }
            }
        }

        StatusText.Text =
            "No supported image found in Clipboard. Copy an image or an image file, then try Paste again.";
    }
    catch (Exception ex)
    {
        AppLog.Write("Could not paste image from clipboard: " + ex);

        StatusText.Text =
            "Could not paste image from clipboard: " + ex.Message;
    }
}

private BitmapSource TryGetClipboardPng(IDataObject data)
{
    try
    {
        string[] formats =
        {
            "PNG",
            "image/png"
        };

        foreach (string format in formats)
        {
            if (!data.GetDataPresent(format, true))
                continue;

            object value = data.GetData(format, true);

            byte[] bytes = value as byte[];

            if (bytes == null)
            {
                Stream sourceStream = value as Stream;

                if (sourceStream != null)
                {
                    using (var memory = new MemoryStream())
                    {
                        if (sourceStream.CanSeek)
                            sourceStream.Position = 0;

                        sourceStream.CopyTo(memory);
                        bytes = memory.ToArray();
                    }
                }
            }

            if (bytes == null || bytes.Length == 0)
                continue;

            using (var stream = new MemoryStream(bytes))
            {
                var image = new BitmapImage();

                image.BeginInit();
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.StreamSource = stream;
                image.EndInit();

                if (image.CanFreeze)
                    image.Freeze();

                return image;
            }
        }
    }
    catch (Exception ex)
    {
        AppLog.Write("Could not read PNG clipboard data: " + ex.Message);
    }

    return null;
}

private void PasteBitmapSource(BitmapSource clipboardImage)
{
    BitmapSource image = clipboardImage.Clone();

    if (image.CanFreeze)
        image.Freeze();

    string tempPath = Path.Combine(
        Path.GetTempPath(),
        "FontFinder_Pasted_" +
        Guid.NewGuid().ToString("N") +
        ".png");

    var encoder = new PngBitmapEncoder();
    encoder.Frames.Add(BitmapFrame.Create(image));

    using (var stream = new FileStream(
        tempPath,
        FileMode.CreateNew,
        FileAccess.Write,
        FileShare.None))
    {
        encoder.Save(stream);
    }

    SetPastedImage(image, tempPath, "Pasted image from Clipboard");
}

private void PasteImageFile(string filePath)
{
    var image = new BitmapImage();

    image.BeginInit();
    image.CacheOption = BitmapCacheOption.OnLoad;
    image.UriSource = new Uri(filePath);
    image.EndInit();

    if (image.CanFreeze)
        image.Freeze();

    SetPastedImage(image, filePath, "Pasted image file: " + Path.GetFileName(filePath));
}

private void SetPastedImage(
    BitmapSource image,
    string imagePath,
    string displayName)
{
    var info = new FileInfo(imagePath);

    InputImage.Source = image;
    _imagePath = imagePath;

    _imageStamp =
        info.LastWriteTimeUtc.Ticks.ToString(CultureInfo.InvariantCulture)
        + ":"
        + info.Length.ToString(CultureInfo.InvariantCulture);

    ImagePathText.Text = displayName;

    ResetCrop();
    ResetImageZoom();

    StatusText.Text =
        "Image pasted successfully. Enter its visible text, then click Find similar fonts.";
}