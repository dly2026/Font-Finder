﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;

namespace FontFinder
{
    /// <summary>Small thread-safe file logger. Logging must never break the application.</summary>
    internal static class AppLog
    {
        private static readonly object Gate = new object();
        private const long MaxBytes = 1024 * 1024;

        public static string LogPath { get; } = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "FontFinder", "Logs", "FontFinder.log");

        public static void Write(string message)
        {
            try
            {
                lock (Gate)
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(LogPath));
                    var info = new FileInfo(LogPath);
                    if (info.Exists && info.Length > MaxBytes) File.Delete(LogPath);
                    string line = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)
                        + "  " + message + Environment.NewLine;
                    File.AppendAllText(LogPath, line, Encoding.UTF8);
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine("FontFinder: could not write log: " + ex.Message);
            }
        }
    }
}
