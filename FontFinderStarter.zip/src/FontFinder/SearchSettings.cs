﻿using System;
using System.Configuration;
using System.Globalization;

namespace FontFinder
{
    /// <summary>Limits read from FontFinder.exe.config (appSettings), clamped to safe ranges.</summary>
    internal static class SearchSettings
    {
        public const int MaxCandidates = 500;
        public const int MaxResults = 100;

        public static int CandidateLimit { get; } = Read("CandidateLimit", MaxCandidates, 20, MaxCandidates);
        public static int ResultLimit { get; } = Read("ResultLimit", MaxResults, 1, MaxResults);

        private static int Read(string key, int fallback, int min, int max)
        {
            try
            {
                string raw = ConfigurationManager.AppSettings[key];
                int value;
                if (!string.IsNullOrWhiteSpace(raw)
                    && int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out value))
                {
                    return Math.Max(min, Math.Min(max, value));
                }
            }
            catch (ConfigurationException ex)
            {
                AppLog.Write("Invalid configuration for '" + key + "': " + ex.Message);
            }
            return fallback;
        }
    }
}
