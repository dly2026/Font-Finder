﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Threading;

namespace FontFinder
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // "FontFinder.exe --selftest [results-file]" runs the built-in checks without opening the UI.
            string[] args = e.Args ?? new string[0];
            if (args.Any(a => string.Equals(a, "--selftest", StringComparison.OrdinalIgnoreCase)))
            {
                string output = args.Length > 1 ? args[1] : null;
                int code = SelfTest.Run(output);
                Shutdown(code);
                return;
            }

            DispatcherUnhandledException += OnDispatcherUnhandledException;
            new MainWindow().Show();
        }

        private static void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            AppLog.Write("Unhandled UI exception: " + e.Exception);
            MessageBox.Show("An unexpected error occurred: " + e.Exception.Message + "\nDetails were written to " + AppLog.LogPath,
                "Font Finder", MessageBoxButton.OK, MessageBoxImage.Error);
            e.Handled = true;
        }
    }
}
