﻿namespace FontFinder
{
    /// <summary>One row of the results grid (also used for the installed-font list).</summary>
    internal sealed class FontRow
    {
        public string Family { get; set; }
        /// <summary>Descriptive category label. Never used as a search filter.</summary>
        public string Category { get; set; }
        public string Style { get; set; }
        public string Similarity { get; set; }
        public double Score { get; set; }

        public FontRow Clone()
        {
            return new FontRow
            {
                Family = Family,
                Category = Category,
                Style = Style,
                Similarity = Similarity,
                Score = Score
            };
        }
    }
}
